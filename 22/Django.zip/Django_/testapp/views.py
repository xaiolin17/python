import subprocess

from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from scrapy.crawler import CrawlerProcess, CrawlerRunner


# Create your views here.

def index(request):
    return HttpResponse(r"Hey man,U can do it!")


def test(request):
    return render(request, 'test/testHtml.html')


@csrf_exempt
def getrept(request):
        # 创建一个CrawlerProcess对象
        #process = CrawlerProcess(settings={
        #    'USER_AGENT': 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
        #})

        # 添加要运行的Spider
        #process.crawl(TestSpider)

        # 启动爬虫
        #process.start()

        # 获取爬取结果
        # items = process.spider.data
        # print(items)

        # 处理爬虫的返回值，并打印出来
        # print("Spider Finished:", spider.name)
        # print("Result:", result)
        # reactor.stop()  # 停止事件循环


        runner = CrawlerRunner()

        # 启动爬虫，并在爬取完成后调用回调函数
        # d = runner.crawl(TestSpider)|
        # d.addBoth(crawl_finished, TestSpider)

        # 运行事件循环以开始爬虫的执行
        # reactor.run()

        if request.method == 'POST':
            # 获取20个筛选条件
            computername = request.POST.get("computername")
            fxvar = request.POST.get("fxvar")
            tcycle = request.POST.get("tcycle")
            eaname = request.POST.get("eaname")
            timelimit = request.POST.get("timelimit")
            reyear = request.POST.get("reyear")

            # -------------------------------------------------#

            xsumprofit = request.POST.get("xsumprofit")
            xprorat = request.POST.get("xprorat")
            xplrat = request.POST.get("xplrat")
            xmaxloss = request.POST.get("xmaxloss")
            xordernum = request.POST.get("xordernum")
            xratewin = request.POST.get("xratewin")
            xprincipalback = request.POST.get("xprincipalback")
            xprofitback = request.POST.get("xprofitback")
            xloss3 = request.POST.get("xloss3")
            xloss5 = request.POST.get("xloss5")
            xshunshou = request.POST.get("xshunshou")
            xnigong = request.POST.get("xnigong")
            xwavespace = request.POST.get("xwavespace")
            weighttype = request.POST.get("weighttype")

            print(request.body)
            print(request.POST.get("computername"))
            response_data = {
                'message': 'Success',
                'data': request.POST.get("computername")
            }


            return JsonResponse(response_data)