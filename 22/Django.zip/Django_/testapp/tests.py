import json
import os
import random
import re
import time

import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


def generate_random_user_agent():
    user_agent = UserAgent()
    return user_agent.random


headers = {
    'user-agent': UserAgent().random,
}


def fetch_ip_list(api_url):
    try:
        response = requests.get(api_url)
        if response.status_code == 200:
            ip_list = response.text.strip().split('\n')
            return ip_list
        else:
            print(f"Failed to fetch IP list. Status code: {response.status_code}")
            return []
    except requests.exceptions.RequestException as e:
        print(f"Error occurred while fetching IP list: {e}")
        return []


api_url = 'http://api.3ip.cn/dmgetip.asp?apikey=c22201df&pwd=0e6064aa6e3521c77e6da0dd87e14f1a&getnum=200&httptype=1&geshi=1&fenge=1&fengefu=&Contenttype=1&operate=all'
ip_list = fetch_ip_list(api_url)
ip_list = [item.replace("\r", "") for item in ip_list]


def get_data_from_url(url):
    random_ip = "http://" + random.choice(ip_list)
    proxies = {'http': random_ip, }
    response = requests.get(url, verify=True, proxies=proxies, headers=headers)
    print(response)
    if response.status_code == 200:
        return response.text
    else:
        return 0


def getSourceHtmlStr(fileUrl):
    options = Options()
    # 启用无界面模式
    options.add_argument('--headless')
    # 创建 Chrome 浏览器驱动
    driver = webdriver.Chrome(options=options)
    driver.get(fileUrl)
    time.sleep(2)
    html = driver.page_source
    driver.quit()
    return html


# ----爬虫执行部分----
# url = "https://www.mql5.com/zh/signals/mt4/trusted/page1"
url = "https://www.mql5.com/zh/signals/mt5/page1"
mt4_single_data = []
index = 1
page = 1
colorlist = ['background:rgb(216,239,217);', 'background:rgb(234,244,222);', 'background:rgb(255,236,209);',
             'background:rgb(250,229,218);', 'background:rgb(249,218,219);']
while 1:
    data = get_data_from_url(url)
    if data:
        # 使用BeautifulSoup解析网页内容 # line 10
        soup = BeautifulSoup(data, "html.parser")

        singleAList = soup.find_all('a', class_="signal-card__wrapper")
        for singleA in singleAList:
            singleA_tag = BeautifulSoup(str(singleA), 'html.parser')
            a_tag = singleA_tag.find('a')
            href_value = a_tag.get('href') if a_tag else None
            singleUrl = r'https://www.mql5.com' + str(href_value)
            singleId = singleUrl.split('?')[0].split('signals/')[1]
            author_name_list = singleA_tag.find_all('span', class_="signal-card__author__item")  # line 20
            authorName = author_name_list[0].text + ' ' + author_name_list[1].text
            singleName = singleA_tag.find_all('span', class_="signal-card__title-wrapper")[0].text
            upRate = singleA_tag.find_all('span', class_="signal-card__growth-value")[0].text.replace(" ", "")
            startYear = ''
            try:
                startYear = singleA_tag.find_all('span', class_="signal-card__growth-label")[0].text
            except IndexError:
                startYear = ''
            riskVal = ''
            try:
                risk_color = singleA_tag.find_all('span', class_=["risk-chart__item", "risk-chart__item_0"])[0]
                risk_color_tag = BeautifulSoup(str(risk_color), 'html.parser')
                risk_tag = risk_color_tag.find('span')
                riskVal = risk_tag.get('style') if a_tag else None
                riskVal = {colorlist[0]: '5', colorlist[1]: '4', colorlist[2]: '3', colorlist[3]: '2',
                           colorlist[4]: '1'}.get(riskVal, '0')
            except IndexError:
                riskVal = ''
            aiTradeRate = singleA_tag.find_all('span', class_="signal-card__algotrading-value")[0].text.strip()
            followNum = singleA_tag.find_all('span', class_="signal-card__subscribers-value")[0].text  # line 40
            preMonth = singleA_tag.find_all('span', class_="signal-card__copy")[0].text.strip()
            print("信号详情：" + singleUrl)
            singleDtail = get_data_from_url(singleUrl)
            if singleDtail:
                # 使用BeautifulSoup解析网页内容
                # -----------------------------信号摘要数据------------------------------
                single_Dtail_Soup = BeautifulSoup(str(singleDtail), "html.parser")
                singleSum = single_Dtail_Soup.find_all('div', class_="s-top-info__left-part")[0]
                singleSum_tag = BeautifulSoup(str(singleSum), 'html.parser')
                author_div = singleSum_tag.find_all('div', class_="s-plain-card__author")[0]   # line 50
                author_div_tag = BeautifulSoup(str(author_div), 'html.parser')
                author_url_tag = BeautifulSoup(str(author_div_tag.find_all('a')[0]), 'html.parser')
                a_author_tag = author_url_tag.find('a')
                authorUrl = a_author_tag.get('href') if a_tag else None
                broker_tag = singleSum_tag.find_all('input', attrs={'name': 'substring_filter'})[0]
                broker = broker_tag.get('value')
                leverage = singleSum_tag.find_all('div', class_="s-plain-card__leverage")[0].text.strip()
                # -----------------------------rader数据------------------------------
                # -----------------------------bar数据------------------------------
                passWeek = ''  # line 60
                try:
                    passWeek = str(single_Dtail_Soup.find_all('span', class_=["s-indicators__item-desc",
                                                                              "s-indicators__item-desc_weeks"])[0]).split(
                        "<span>")[1].split("</span>")[0].replace(" ", "")
                except IndexError:
                    passWeek = '0'
                followFund = single_Dtail_Soup.find("div", title="考虑使用风险的真实账户的全部资金").text
                # ------------------------------摘要左边数据------------------------------------
                columns1 = single_Dtail_Soup.find_all('div', id="tradeDataColumns")[0]
                columnsValue1_tag = BeautifulSoup(str(columns1), "html.parser")  # line 70
                columns1_value = columnsValue1_tag.find_all('div', class_="s-data-columns__value")
                tradeNum = columns1_value[0].text.replace(" ", "")
                winNum = columns1_value[1].text.replace(" ", "")
                winRate = winNum.split("(")[1].split(")")[0]
                lossNum = columns1_value[2].text.replace(" ", "")
                maxPtrade = columns1_value[3].text.strip()
                maxLtrade = columns1_value[4].text.strip()
                grossProfit = columns1_value[5].text.strip()
                grossLoss = columns1_value[6].text.strip()
                maxContinuousProfitNum = columns1_value[7].text.strip()  # line 80
                maxContinuousProfit = columns1_value[8].text.strip()
                sharp = columns1_value[9].text
                tradeAct = columns1_value[10].text
                maxIn = columns1_value[11].text
                LastTrade = columns1_value[12].text
                preWeekNum = columns1_value[13].text
                avgPassTime = columns1_value[14].text
                # -------------------------------摘要右边数据------------------------------------
                recoveryRate = columns1_value[15].text
                longTrade = columns1_value[16].text.replace(" ", "")  # line 90
                shortTrade = columns1_value[17].text.replace(" ", "")
                profitTactor = columns1_value[18].text.replace(" ", "")
                preIn = columns1_value[19].text.strip().replace(" ", "")
                avgPro = columns1_value[20].text.strip().replace(" ", "")
                avgLoss = columns1_value[21].text.strip().replace(" ", "")
                rrr = 0.00
                try:
                    if float(avgLoss.split(".")[0] + "." + avgLoss.split(".")[1][:2]) != 0:
                        rrr = round(float(avgPro.split(".")[0] + "." + avgPro.split(".")[1][:2]) / float(
                            avgLoss.split(".")[0] + "." + avgLoss.split(".")[1][:2]), 2)  # 没考虑被除数为0 的形式
                except IndexError:
                    rrr = 0.00
                maxContinuousLossNum = columns1_value[22].text.strip().replace(" ", "")
                maxContinuousLoss = columns1_value[23].text.strip().replace(" ", "")
                monthUp = columns1_value[24].text.strip().replace(" ", "")
                yearPredict = ''
                try:
                    yearPredict = columns1_value[25].text.strip().replace(" ", "")
                except IndexError:
                    yearPredict = ''
                # ---------------取相对最大跌幅------------------
                columns2 = single_Dtail_Soup.find_all('div', id="risksTradeDataColumns")[0]
                columnsValue2_tag = BeautifulSoup(str(columns2), "html.parser")  # line 70
                columns2_value = columnsValue2_tag.find_all('div', class_="s-data-columns__value")
                absLoss = columns2_value[6].text.strip().replace(" ", "")
                absLoss = absLoss.split(".")[0] + "." + absLoss.split(".")[1][:2]
                jieyuMaxBack = columns2_value[8].text.strip().replace(" ", "")
                jinzhiMaxBack = columns2_value[9].text.strip().replace(" ", "")

                # 数据整理
                single = {"singleId": singleId, "singleUrl": singleUrl, "authorName": authorName,
                          "singleName": singleName,
                          "upRate": upRate, "startYear": startYear, "aiTradeRate": aiTradeRate, "followNum": followNum,
                          "preMonth": preMonth, "authorUrl": authorUrl, "broker": broker, "leverage": leverage,
                          "passWeek": passWeek, "followFund": followFund,
                          "netWorth": "", "netProfit": "", "seedIn": "", "cashOut": "", "cashIn": "",
                          "sumIn": "", "sumNetWorth": "", "profitRat": "",
                          "tradeNum": tradeNum, "winNum": winNum, "winRate": winRate, "lossNum": lossNum,
                          "maxPtrade": maxPtrade,
                          "maxLtrade": maxLtrade, "grossProfit": grossProfit, "grossLoss": grossLoss,
                          "maxContinuousProfitNum": maxContinuousProfitNum, "maxContinuousProfit": maxContinuousProfit,
                          "sharp": sharp, "tradeAct": tradeAct, "maxIn": maxIn, "LastTrade": LastTrade,
                          "preWeekNum": preWeekNum,
                          "avgPassTime": avgPassTime, "recoveryRate": recoveryRate, "longTrade": longTrade,
                          "shortTrade": shortTrade, "profitTactor": profitTactor, "preIn": preIn, "avgPro": avgPro,
                          "avgLoss": avgLoss, "rrr": rrr, "maxContinuousLossNum": maxContinuousLossNum,
                          "maxContinuousLoss": maxContinuousLoss, "monthUp": monthUp, "yearPredict": "",
                          "absLoss": absLoss, "jieyuMaxBack": jieyuMaxBack, "jinzhiMaxBack": jinzhiMaxBack}
                mt4_single_data.append(single)
            index += 1
            print(index - 1)


    else:
        break
    # 爬取下一页
    page += 1
    url = re.sub(r'page\d+', 'page', url) + str(page)
    print("翻页的：" + url)
    time.sleep(2)
file_path = os.path.expanduser("C:/Users/Administrator/Desktop/data.json")

with open(file_path, 'w') as file:
    json.dump(mt4_single_data, file)

# 初始化一个空字典来存储合并后的数据
merged_MT4data = {}

# 遍历 all_mt4data 列表中的每个字典
for MT4data in all_mt4data:
    # 使用 for 循环手动合并字典
    print(len(MT4data['信号详情页']))
    for key, value in MT4data.items():
        if key in merged_MT4data:
            # 如果键已经存在于 merged_MT4data 中，可以根据实际需求选择处理方式
            merged_MT4data[key].extend(value)
        else:
            merged_MT4data[key] = value

# Convert the dictionary to a JSON string
json_string = json.dumps(merged_MT4data)

# Save the JSON string to a file
with open("MT4signal.json", "w") as file:
    file.write(json_string)


# 入库操作
import json
import mysql.connector

# 读取 JSON 文件
with open('C:/Users/Administrator/Desktop/data.txt', 'r', encoding='utf-8') as file:
    json_data = json.load(file)

# 建立数据库连接
db_connection = mysql.connector.connect(
    host='192.168.1.5',
    user='zq123',
    password='zq123',
    database='zhiqiangdb'
)

# 创建游标对象
cursor = db_connection.cursor()

# 循环遍历 JSON 数据，插入到数据库中
for item in json_data:
    # 解析 JSON 数据
    keywords = item['keywords']
    grade = item['grade']
    type = item['type']


    # 构建插入语句
    insert_query = "INSERT INTO keys_words (keywords, grade, type) " \
                   "VALUES (%s, %s, %s)"
    values = (keywords, grade, type)

    # 执行插入操作
    cursor.execute(insert_query, values)

# 提交更改到数据库
db_connection.commit()

# 关闭游标和数据库连接
cursor.close()
db_connection.close()


# 入库操作
import json
import mysql.connector

# 读取 JSON 文件
with open('C:/Users/Administrator/Desktop/data.txt', 'r', encoding='utf-8') as file:
    json_data = json.load(file)

# 建立数据库连接
db_connection = mysql.connector.connect(
    host='192.168.1.5',
    user='zq123',
    password='zq123',
    database='zhiqiangdb'
)

# 创建游标对象
cursor = db_connection.cursor()

# 循环遍历 JSON 数据，插入到数据库中
for item in json_data:
    # 解析 JSON 数据
    singleId = item['singleId']
    singleUrl = item['singleUrl']
    authorName = item['authorName']
    singleName = item['singleName']
    upRate = item['upRate']
    startYear = item['startYear']
    aiTradeRate = item['aiTradeRate']
    followNum = item['followNum']
    preMonth = item['preMonth']
    authorUrl = item['authorUrl']
    broker = item['broker']
    leverage = item['leverage']
    passWeek = item['passWeek']
    followFund = item['followFund']
    netWorth = item['netWorth']
    netProfit = item['netProfit']
    seedIn = item['seedIn']
    cashOut = item['cashOut']
    cashIn = item['cashIn']
    sumIn = item['sumIn']
    sumNetWorth = item['sumNetWorth']
    profitRat = item['profitRat']
    tradeNum = item['tradeNum']
    winNum = item['winNum']
    winRate = item['winRate']
    lossNum = item['lossNum']
    maxPtrade = item['maxPtrade']
    maxLtrade = item['maxLtrade']
    grossProfit = item['grossProfit']
    grossLoss = item['grossLoss']
    maxContinuousProfitNum = item['maxContinuousProfitNum']
    maxContinuousProfit = item['maxContinuousProfit']
    sharp = item['sharp']
    tradeAct = item['tradeAct']
    maxIn = item['maxIn']
    LastTrade = item['LastTrade']
    preWeekNum = item['preWeekNum']
    avgPassTime = item['avgPassTime']
    recoveryRate = item['recoveryRate']
    longTrade = item['longTrade']
    shortTrade = item['shortTrade']
    profitTactor = item['profitTactor']
    preIn = item['preIn']
    avgPro = item['avgPro']
    avgLoss = item['avgLoss']
    rrr = item['rrr']
    maxContinuousLossNum = item['maxContinuousLossNum']
    maxContinuousLoss = item['maxContinuousLoss']
    monthUp = item['monthUp']
    yearPredict = item['yearPredict']
    absLoss = item['absLoss']
    jieyuMaxBack = item['jieyuMaxBack']
    jinzhiMaxBack = item['jinzhiMaxBack']


    # 构建插入语句
    insert_query = "INSERT INTO keys_words (singleId, singleUrl, authorName, singleName, upRate, startYear, " \
                   "aiTradeRate, followNum, preMonth, authorUrl, broker, leverage, passWeek, followFund, " \
                   "netWorth, netProfit, seedIn, cashOut, cashIn, sumIn, sumNetWorth, profitRat, tradeNum, " \
                   "winNum, winRate, lossNum, maxPtrade, maxLtrade, grossProfit, grossLoss, maxContinuousProfitNum, " \
                   "maxContinuousProfit, sharp,tradeAct,maxIn,LastTrade,preWeekNum,avgPassTime,recoveryRate," \
                   "longTrade,shortTrade,profitTactor,preIn,avgPro,avgLoss,rrr,maxContinuousLossNum," \
                   "maxContinuousLoss,monthUp,yearPredict,absLoss,jieyuMaxBack,jinzhiMaxBack) " \
                   "VALUES (%s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, " \
                   "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, " \
                   "%s, %s, %s, %s,%s, %s, %s)"
    values = (singleId, singleUrl, authorName, singleName, upRate, startYear,
              aiTradeRate, followNum, preMonth, authorUrl, broker, leverage, passWeek, followFund,
              netWorth, netProfit, seedIn, cashOut, cashIn, sumIn, sumNetWorth, profitRat, tradeNum,
              winNum, winRate, lossNum, maxPtrade, maxLtrade, grossProfit, grossLoss, maxContinuousProfitNum,
              maxContinuousProfit, sharp,tradeAct,maxIn,LastTrade,preWeekNum,avgPassTime,recoveryRate,
              longTrade,shortTrade,profitTactor,preIn,avgPro,avgLoss,rrr,maxContinuousLossNum,
              maxContinuousLoss,monthUp,yearPredict,absLoss,jieyuMaxBack,jinzhiMaxBack)

    # 执行插入操作
    cursor.execute(insert_query, values)

# 提交更改到数据库
db_connection.commit()

# 关闭游标和数据库连接
cursor.close()
db_connection.close()