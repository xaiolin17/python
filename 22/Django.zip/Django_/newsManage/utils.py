import random
import time
from datetime import datetime

import requests
from fake_useragent import UserAgent
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

from newsManage.models import KeyWords


def get_data_from_url(url):
    headers = {
        'user-agent': UserAgent().random,
    }
    api_url = 'http://api.3ip.cn/dmgetip.asp?apikey=c22201df&pwd=0e6064aa6e3521c77e6da0dd87e14f1a&getnum=200&httptype=1&geshi=1&fenge=1&fengefu=&Contenttype=1&operate=all'
    ip_list = fetch_ip_list(api_url)
    ip_list = [item.replace("\r", "") for item in ip_list]
    random_ip = "http://" + random.choice(ip_list)
    proxies = {'http': random_ip, }
    response = requests.get(url, verify=True, proxies=proxies, headers=headers)
    print(response)
    if response.status_code == 200:
        return response.text
    else:
        return 0


def fetch_ip_list(api_url):
    try:
        response = requests.get(api_url)
        if response.status_code == 200:
            ip_list = response.text.strip().split('\n')
            return ip_list
        else:
            print(f"Failed to fetch IP list. Status code: {response.status_code}")
            return []
    except requests.exceptions.RequestException as e:
        print(f"Error occurred while fetching IP list: {e}")
        return []


def getHtmlUseSelenium(url):
    options = Options()
    # 启用无界面模式
    # options.add_argument('--headless')
    # 创建 Chrome 浏览器驱动
    driver = webdriver.Chrome(options=options)
    time.sleep(1)
    driver.get(url)
    time.sleep(5)
    # 设置等待时间
    # wait = WebDriverWait(driver, 5)
    # # 等待页面加载完成
    # wait.until(EC.presence_of_element_located((By.TAG_NAME, 'body')))
    html = driver.page_source
    driver.quit()
    return html

def getHtmlUseSeleniumJinshi(url):
    '''
    金十专用
    :param url
    :return: html
    '''

    options = Options()
    # 启用无界面模式
    # options.add_argument('--headless')
    # 创建 Chrome 浏览器驱动
    driver = webdriver.Chrome(options=options)
    driver.get(url)
    # 获取加载更多标签
    a = driver.find_element(By.XPATH, "//a[@class='load-more']")
    # 通过js点击加载更多10次，每次等待0.2s
    for i in range(10):
        driver.execute_script("arguments[0].click();", a)
        time.sleep(0.2)
    html = driver.page_source
    driver.quit()
    return html


def getHtmlRoll(url):
    options = Options()
    # 启用无界面模式
    # options.add_argument('--headless')
    # 创建 Chrome 浏览器驱动
    driver = webdriver.Chrome(options=options)
    time.sleep(1)
    driver.get(url)
    time.sleep(1)

    # 获取当前页面的高度
    last_height = driver.execute_script("return document.body.scrollHeight")
    # 模拟下拉操作，直到滑动到底部
    while True:
        # 模拟下拉操作
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(0.3)
        # 获取当前页面的高度
        new_height = driver.execute_script("return document.body.scrollHeight")
        # 判断是否已经到达页面底部
        if new_height == last_height:
            break
        # 继续下拉操作
        last_height = new_height
    html = driver.page_source
    driver.quit()
    return html


# 入参字典类型的list
def markInfo(newsList):
    data = KeyWords.objects.all()
    keyWordslist = list(data.values("keywords"))

    keyWordsSet = set(item["keywords"] for item in keyWordslist)
    resList = []
    for news in newsList:
        for keyWords in keyWordsSet:
            if keyWords in news["newsTitle"]:
                grade = KeyWords.objects.filter(keywords=keyWords).values_list('grade', flat=True)
                news = {"newsTitle": str(news["newsTitle"]).replace(keyWords,"<span class='important"
                                                                    + str(grade[0]) + "'>" + keyWords + "</span>")}

        resList.append(news)
    return resList


def stcnMarkInfo(newsList):
    data = KeyWords.objects.all()
    keyWordslist = list(data.values("keywords"))

    keyWordsSet = set(item["keywords"] for item in keyWordslist)
    resList = []
    for news in newsList:
        for keyWords in keyWordsSet:
            if keyWords in news["newsTitle"]:
                grade = KeyWords.objects.filter(keywords=keyWords).values_list('grade', flat=True)
                news = {"newsTime":news["newsTime"],
                        "newsTitle": str(news["newsTitle"]).replace(keyWords,"<span class='important"
                                                                    + str(grade[0]) + "'>" + keyWords + "</span>"),
                        "newsContent":news["newsContent"]}

        resList.append(news)
    return resList

# 定义一个自定义函数将 datetime 对象序列化为字符串
def serialize_datetime(obj):
    if isinstance(obj, datetime):
        return obj.strftime('%Y-%m-%d %H:%M:%S')
    raise TypeError(f'Object of type {obj.__class__.__name__} is not JSON serializable')
