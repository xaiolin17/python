import datetime
import json

from bs4 import BeautifulSoup
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from newsManage.handler import mergeIntoKeywords, delKeywords, mergeIntoRecStocks, selectRecStocks
from newsManage.utils import get_data_from_url, getHtmlUseSelenium, getHtmlRoll, markInfo, stcnMarkInfo, \
    serialize_datetime


def tonews(request):
    return render(request, 'newsManage/news.html')

# Create your views here.
@csrf_exempt
def getHotNews(request):
    try:
        if request.method == 'POST':
            # 热搜 用request
            baiduUrl = "https://top.baidu.com/board?tab=realtime"
            douyinUrl = "https://www.douyin.com/hot"
            xinlangUrl = "https://s.weibo.com/top/summary?cate=realtimehot"
            stcnUrl = "http://www.stcn.com/article/list/kx"
            baidulist = []
            baidudata = get_data_from_url(baiduUrl)
            if baidudata:
                soup = BeautifulSoup(baidudata, "html.parser")
                newsList = soup.find_all('div', class_="c-single-text-ellipsis")

                for news in newsList:
                    newsTitle = news.text.replace('"', '-').replace('\'', '-').strip()
                    newsDict = {"newsTitle":newsTitle}
                    baidulist.append(newsDict)

            douyinlist = []
            douyindata = getHtmlUseSelenium(douyinUrl)
            if douyindata:
                soup = BeautifulSoup(douyindata, "html.parser")
                newsList = soup.select('a.B3AsdZT9.mmjTMnlA')

                for news in newsList:
                    newsTitle = news.text.replace('"', '-').replace('\'', '-').strip()
                    newsDict = {"newsTitle": newsTitle}
                    douyinlist.append(newsDict)

            xinlanglist = []
            xinlangdata = getHtmlUseSelenium(xinlangUrl)
            if xinlangdata:
                soup = BeautifulSoup(xinlangdata, "html.parser")
                newsList = soup.find_all('td', class_="td-02")

                for news in newsList:
                    newsTitle = news.text.replace("\n"," ").replace('"', '-').replace('\'', '-').strip()
                    newsDict = {"newsTitle": newsTitle}
                    xinlanglist.append(newsDict)

            stcnlist = []
            stcndata = getHtmlRoll(stcnUrl)
            if stcndata:
                soup = BeautifulSoup(stcndata, "html.parser")
                newsUl = soup.select('ul.quick-news-list.infinite-list')[0]
                newsLi = BeautifulSoup(str(newsUl), 'html.parser')
                newsLiList = newsLi.find_all('li')
                for newsLi in newsLiList:
                    a_tag = BeautifulSoup(str(newsLi), 'html.parser')
                    newsTime = a_tag.find_all('div', class_="time")[0].text
                    newsTitle = a_tag.find_all('div', class_="title")[0].text\
                        .replace('"', '-').replace('\'', '-').strip()
                    newsContent = a_tag.find_all('div', class_="content")[0].text\
                        .replace("\n"," ").replace('"', '-').replace('\'', '-').replace("\xa0", " ").strip()
                    newsDict = {"newsTime": newsTime,"newsTitle": newsTitle,"newsContent": newsContent}
                    stcnlist.append(newsDict)
            baidulist = markInfo(baidulist)
            douyinlist = markInfo(douyinlist)
            xinlanglist = markInfo(xinlanglist)
            stcnlist = stcnMarkInfo(stcnlist)
            # 财经新闻
            response_data = {
                'message': 'Success',
                'baidulist': str(baidulist),
                'douyinlist': str(douyinlist),
                'xinlanglist': str(xinlanglist),
                'stcnlist': str(stcnlist),
            }
            return JsonResponse(response_data)
    except Exception as e:
        print(e)
        error_message = '请求失败! ' + str(e)
        return HttpResponse(error_message)


@csrf_exempt
def addKeysWords(request):
    try:
        if request.method == 'POST':
            keysWords = request.POST.get("keysWords")
            grade = request.POST.get("grade")
            addOrUpdateDict = {'keywords': keysWords,
                               'grade': grade
                               }
            resId = mergeIntoKeywords(addOrUpdateDict)
            message = ''
            if resId > 0:
                message = 'Success'
            response_data = {
                'message': message,
            }
            return JsonResponse(response_data)
    except Exception as e:
        print(e)
        error_message = '请求失败! ' + str(e)
        return HttpResponse(error_message)


@csrf_exempt
def delKeysWords(request):
    try:
        if request.method == 'POST':
            keysWords = request.POST.get("keysWords")
            grade = request.POST.get("grade")
            addOrUpdateDict = {'keywords': keysWords,
                               'grade': grade
                               }
            resId = delKeywords(addOrUpdateDict)
            message = ''
            if resId > 0:
                message = 'Success'
            response_data = {
                'message': message,
            }
            return JsonResponse(response_data)
    except Exception as e:
        print(e)
        error_message = '请求失败! ' + str(e)
        return HttpResponse(error_message)


@csrf_exempt
def addRecStocks(request):
    try:
        if request.method == 'POST':
            recStocks = request.POST.get("recStocks")
            reason = request.POST.get("reason")
            sponsor = request.POST.get("sponsor")
            current_time = datetime.datetime.now()
            mysql_time_format = current_time.strftime("%Y-%m-%d %H:%M:%S")
            addOrUpdateDict = {'recStocks': recStocks,
                               'reason': reason,
                               'sponsor': sponsor,
                               'recTime': mysql_time_format
                               }
            resId = mergeIntoRecStocks(addOrUpdateDict)
            message = ''
            if resId > 0:
                message = 'Success'
            response_data = {
                'message': message,
            }
            return JsonResponse(response_data)
    except Exception as e:
        print(e)
        error_message = '请求失败! ' + str(e)
        return HttpResponse(error_message)


@csrf_exempt
def getRecStocks(request):
    try:
        if request.method == 'POST':
            results = selectRecStocks()
            # 将 QuerySet 转换为列表
            recStocks_list = list(results.values())
            # 对列表进行 JSON 序列化
            json_data = json.dumps(recStocks_list, default=serialize_datetime)
            message = ''
            if results is not None:
                message = 'Success'
            results_str = json_data.encode('utf-8').decode('unicode_escape')
            response_data = {
                'message': message,
                'results':results_str
            }
            print(response_data)
            return JsonResponse(response_data)
    except Exception as e:
        print(e)
        error_message = '查询失败! ' + str(e)
        return HttpResponse(error_message)
# @csrf_exempt
# def getKeywordsFJukuan(request):
#     try:
#         if request.method == 'POST':
#             # 初始化聚宽
#             jq.auth('13675871394', 'Jk123456.')
#
#             # 获取A股所有股票名称和简称
#             stocks_a = jq.get_all_securities(types=['stock'], exchanges=['sh'])
#             print(stocks_a[['display_name']])
#
#             # 获取港股所有股票名称和简称
#             stocks_hk = jq.get_all_securities(types=['stock'], exchanges=['hk'])
#             print(stocks_hk[['display_name']])
#
#             # 获取所有板块名称
#             industries = jq.get_all_industries()
#             print(industries)
#     except Exception as e:
#         print(e)
#         error_message = '请求失败! ' + str(e)
#         return HttpResponse(error_message)