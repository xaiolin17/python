from django.db import models


# Create your models here.
class KeyWords(models.Model):
    keywords = models.CharField(max_length=255, null=True, blank=True, verbose_name='关键字')
    grade = models.CharField(max_length=255, null=True, blank=True, verbose_name='等级')
    type = models.CharField(max_length=255, null=True, blank=True, verbose_name='类型')
    name = models.CharField(max_length=255, null=True, blank=True, verbose_name='简称')
    notes = models.CharField(max_length=255, null=True, blank=True, verbose_name='备注')

    class Meta:
        db_table = 'keys_words'


class RecStocks(models.Model):
    recStocks = models.TextField(null=True, blank=True, verbose_name='推荐股票')
    reason = models.TextField(null=True, blank=True, verbose_name='推荐理由')
    sponsor = models.CharField(max_length=255, null=True, blank=True, verbose_name='推荐人')
    remark = models.CharField(max_length=255, null=True, blank=True, verbose_name='备注')
    recTime = models.DateTimeField(null=True, blank=True, verbose_name='推荐时间')

    class Meta:
        db_table = 'rec_stocks'
