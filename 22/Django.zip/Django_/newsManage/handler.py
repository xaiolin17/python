from newsManage.models import KeyWords, RecStocks


def mergeIntoKeywords(paramsdict):
    # 根据标题判断记录是否存在
    try:
        records = KeyWords.objects.filter(keywords=paramsdict['keywords'])
        count = len(records)
        if count == 0:
            # 记录不存在，进行新增操作
            KeyWords.objects.create(**paramsdict)
        else:
            KeyWords.objects.filter(keywords=paramsdict['keywords']).update(
                grade=paramsdict['grade'])
    except KeyWords.DoesNotExist:
        return -1
    return 1


def delKeywords(paramsdict):
    # 根据标题判断记录是否存在
    try:
        records = KeyWords.objects.filter(keywords=paramsdict['keywords'])
        count = len(records)
        if count == 0:
            # 记录不存在，删除成功
            return 1
        else:
            KeyWords.objects.filter(keywords=paramsdict['keywords']).delete()
    except KeyWords.DoesNotExist:
        return -1
    return 1


def mergeIntoRecStocks(paramsdict):
    # 根据标题判断记录是否存在
    try:
        records = RecStocks.objects.filter(sponsor=paramsdict['sponsor'])
        count = len(records)
        if count == 0:
            # 记录不存在，进行新增操作
            RecStocks.objects.create(**paramsdict)
        else:
            RecStocks.objects.filter(sponsor=paramsdict['sponsor']).update(
                recStocks=paramsdict['recStocks'], reason=paramsdict['reason'], recTime=paramsdict['recTime'])
    except RecStocks.DoesNotExist:
        return -1
    return 1


def selectRecStocks():
    # 根据标题判断记录是否存在
    try:
        # 查询所有记录
        results = RecStocks.objects.all()
    except RecStocks.DoesNotExist:
        return None
    return results
