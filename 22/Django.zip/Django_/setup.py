import glob

from setuptools import find_packages, setup

files = glob.glob('templates/*')  # 替换成您的文件夹路径

setup(
    name='zhiqiang',
    version='1.0',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'zhiqiang': files,
    },
    install_requires=[
            'django',
        ],
)
