import io
import json
import os
import zipfile
import concurrent.futures

from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers

from reportDle.handler import mergeIntoRpt, intoRptOrd, selectRptSummary, queryOrdStopTandStoppById
from reportDle.utils import *


def mtrd(request):
    return render(request, 'reportDle/mql5reportdel.html')


@csrf_exempt
def tosrchrpt(request):
    if request.method == 'POST':
        paramsdict = {}
        # 获取50个筛选条件
        paramsdict['timelimit'] = request.POST.get("timelimit")  # 时间限制
        paramsdict['tunmo'] = request.POST.get("tunmo")  # 吞没
        paramsdict['yingxian'] = request.POST.get("yingxian")  # 影线
        paramsdict['atr'] = request.POST.get("atr")  # ART
        paramsdict['shiti'] = request.POST.get("shiti")  # 实体
        paramsdict['yingxianbi'] = request.POST.get("yingxianbi")  # 影线比
        paramsdict['dak'] = request.POST.get("dak")  # 大K
        paramsdict['muzi'] = request.POST.get("muzi")  # 母子形态
        paramsdict['muzibi'] = request.POST.get("muzibi")  # 母子比
        paramsdict['fanzhuan'] = request.POST.get("fanzhuan")  # 反转形态
        paramsdict['pianyi'] = request.POST.get("pianyi")  # 偏移
        paramsdict['zhiying'] = request.POST.get("zhiying")  # 止盈
        paramsdict['zhisun'] = request.POST.get("zhisun")  # 止损
        paramsdict['kdj'] = request.POST.get("kdj")  # kdj
        paramsdict['shijian'] = request.POST.get("shijian")  # 时间

        # -------------------------------------------------#
        paramsdict['symbol'] = request.POST.get("symbol")  # 品种
        paramsdict['timeframe'] = request.POST.get("timeframe")  # 交易周期
        paramsdict['leverage'] = request.POST.get("leverage")  # 杠杆
        paramsdict['passtavg'] = request.POST.get("passtavg")  # 平均持仓时间
        paramsdict['passtmax'] = request.POST.get("passtmax")  # 最大持仓时间
        paramsdict['passtmin'] = request.POST.get("passtmin")  # 最小持仓时间
        paramsdict['sharpe'] = request.POST.get("sharpe")  # 夏普比率
        paramsdict['totalprofit'] = request.POST.get("totalprofit")  # 净盈利
        paramsdict['maxPreloss'] = request.POST.get("maxPreloss")  # 最大结余亏损
        paramsdict['maxnetloss'] = request.POST.get("maxnetloss")  # 最大净值亏损
        paramsdict['profit_total'] = request.POST.get("profit_total")  # 总盈利
        paramsdict['loss_total'] = request.POST.get("loss_total")  # 总亏损
        paramsdict['maxseedin'] = request.POST.get("maxseedin")  # 最大入金加载
        paramsdict['profitFactor'] = request.POST.get("profitFactor")  # 盈利因子
        paramsdict['fluctions'] = request.POST.get("fluctions")  # 波动率
        paramsdict['winrate'] = request.POST.get("winrate")  # 胜率
        paramsdict['benjinProfitRate'] = request.POST.get("benjinProfitRate")  # 本金收益率
        paramsdict['ordernum'] = request.POST.get("ordernum")  # 交易单量
        paramsdict['buynum'] = request.POST.get("buynum")  # 买单量
        paramsdict['sellnum'] = request.POST.get("sellnum")  # 卖单量
        paramsdict['tpnum'] = request.POST.get("tpnum")  # 盈利单量
        paramsdict['slnum'] = request.POST.get("slnum")  # 亏损单量
        paramsdict['avgRev'] = request.POST.get("avgRev")  # 平均盈利
        paramsdict['minRev'] = request.POST.get("minRev")  # 最小盈利
        paramsdict['maxRev'] = request.POST.get("maxRev")  # 最大盈利
        paramsdict['maxfotp'] = request.POST.get("maxfotp")  # 最大浮盈
        paramsdict['avgfotp'] = request.POST.get("avgfotp")  # 平均浮盈
        paramsdict['maxfosl'] = request.POST.get("maxfosl")  # 最大浮亏
        paramsdict['avgfosl'] = request.POST.get("avgfosl")  # 平均浮亏
        paramsdict['maxbenjinback'] = request.POST.get("maxbenjinback")  # 最大本金回撤
        paramsdict['maxlirunback'] = request.POST.get("maxlirunback")  # 最大利润回撤
        paramsdict['continuLossNum'] = request.POST.get("continuLossNum")  # 最大亏损次数
        paramsdict['continuProfitNum'] = request.POST.get("continuProfitNum")  # 最大盈利次数
        paramsdict['continuLossMoney'] = request.POST.get("continuLossMoney")  # 最大连续亏损金额
        paramsdict['continuProfitMoney'] = request.POST.get("continuProfitMoney")  # 最大连续盈利金额
        paramsdict['shunshou'] = request.POST.get("shunshou")  # 顺守
        paramsdict['nigong'] = request.POST.get("nigong")  # 逆功
        paramsdict['loss3'] = request.POST.get("loss3")  # 连续亏损3次的数目
        paramsdict['loss5'] = request.POST.get("loss5")  # 连续亏损5次的数目
        paramsdict['weekNum'] = request.POST.get("weekNum")  # 周数
        paramsdict['weekProfitMoney'] = request.POST.get("weekProfitMoney")  # 平均周盈利能力
        paramsdict['weekProfitNum'] = request.POST.get("weekProfitNum")  # 平均周交易次数
        paramsdict['weekProfitrate'] = request.POST.get("weekProfitrate")  # 平均周增长率
        paramsdict['monthNum'] = request.POST.get("monthNum")  # 月数
        paramsdict['monthProfitMoney'] = request.POST.get("monthProfitMoney")  # 平均月盈利能力
        paramsdict['monthProfitNum'] = request.POST.get("monthProfitNum")  # 平均月交易次数
        paramsdict['monthProfitrate'] = request.POST.get("monthProfitrate")  # 平均月增长率
        paramsdict['ylrank'] = request.POST.get("ylrank")  # 盈利评分
        paramsdict['bsrank'] = request.POST.get("bsrank")  # 保守评分
        paramsdict['jcrank'] = request.POST.get("jcrank")  # 加仓评分

        filtered_objects = selectRptSummary(paramsdict)
        json_objects = serializers.serialize('json', filtered_objects)
        json_data = json.loads(json_objects)
        fields_only_data = [obj['fields'] for obj in json_data]
        json_string = json.dumps(fields_only_data, ensure_ascii=False)
        json_string = json_string.replace('null', '""')

        char1legend = '['
        char1data = ''
        for hisOrder in filtered_objects:
            char1legend += "'" + hisOrder.reportname + "',"
            result = queryOrdStopTandStoppById(hisOrder.id, str(hisOrder.reporttime))
            orderData = ''
            for res in result:
                orderData += "['" + str(res[0].strftime("%Y-%m-%d %H:%M:%S")) + "'," + str(res[1]) + ']' + ","
            char1data += "{name:'" + hisOrder.reportname + "',type: 'line', showSymbol: false," + "data: [" + orderData + "]},"
        char1legend += "]"
        response_data = {
            'message': 'Success',
            'table1data': json_string,
            'char1legend': char1legend,
            'char1data': char1data,
        }
        return JsonResponse(response_data)


def handle_upload(user_id, file_name):
    # 在这里执行上传文件的操作，根据具体情况修改代码
    print(f"User {user_id} is uploading file: {file_name}")

    # ...执行上传操作...
    print(f"User {user_id} uploaded file: {file_name}")


@csrf_exempt
def rptUpload(request):
    # 创建一个互斥锁
    # upload_lock = threading.Lock()
    # try:
    if request.method == 'POST':
        file = request.FILES['file']

        desktop_path = os.path.expanduser(r"C:\Users\Administrator\Desktop")

        # 创建临时文件夹tmp
        tmp_path = os.path.join(desktop_path, 'tmp')
        os.makedirs(tmp_path, exist_ok=True)  # 如果tmp文件夹已经存在则不报错，没有则创建

        # 检查上传的文件是否为zip类型, 并将它放到tmp文件夹里面
        if file.content_type == 'application/zip' or file.name.endswith('.zip'):
            # 创建一个ZipFile对象
            with zipfile.ZipFile(file, 'r') as zip_ref:
                # 解压缩文件到目标路径
                zip_ref.extractall(tmp_path)

            # 文件数据移动到数据库，并移动到upload文件里面
            # 确保源文件夹和目标文件夹存在
            source_folder = tmp_path
            destination_folder = os.path.join(desktop_path, 'upload')  # upload文件夹
            if not os.path.exists(source_folder):
                print(f"Error: Source folder '{source_folder}' does not exist.")
                return

            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder)

            # 获取源文件夹中的所有文件列表
            files = os.listdir(source_folder)

            # # 锁
            # if upload_lock.acquire(blocking=False):
            # upload_lock.acquire()
            # 移动每个文件到目标文件夹
            # 各个指标阈值

            for file in files:

                source_file_path = os.path.join(source_folder, file)
                destination_file_path = os.path.join(destination_folder, file)

                # 读取文件内容
                with open(source_file_path, 'r', encoding='utf-8') as source_file:
                    file_data = source_file.read()

                fileurl = 'file:///' + source_file_path
                wAmdataDict = getWeekAndMonthData(fileurl)

                # 得到评分

                # 各个指标真值
                totalprofit = float(getHtmlVar(file_data, 'totalprofit'))
                profitFactor = float(getHtmlVar(file_data, 'profitFactor'))
                winrate = float(getHtmlVar(file_data, 'winrate'))
                benjinProfitRate = float(getHtmlVar(file_data, 'benjinProfitRate'))
                maxbenjinback = float(getHtmlVar(file_data, 'maxbenjinback'))
                maxlirunback = float(getHtmlVar(file_data, 'maxlirunback'))
                ordernum = float(getHtmlVar(file_data, 'ordernum'))
                maxPreloss = float(getHtmlVar(file_data, 'maxPreloss'))
                fluctions = float(getHtmlVar(file_data, 'fluctions'))
                avgRev = float(getHtmlVar(file_data, 'avgRev'))
                weekProfitMoney = float(wAmdataDict['weekProfitMoney'])
                mouthProfitMoney = float(wAmdataDict['mouthProfitMoney'])
                shunshou = float(getHtmlVar(file_data, 'shunshou'))  # 越小越好
                nigong = float(getHtmlVar(file_data, 'nigong'))  # 越大越好

                ylrank = (totalprofit / totalprofitYZ) * yllist[0] + (profitFactor / profitFactorYZ) * yllist[1] + (
                        winrate / winrateYZ) * yllist[2] + (benjinProfitRate / benjinProfitRateYZ) * yllist[3] + \
                         (1 - maxbenjinback / maxbenjinbackYZ) * yllist[4] + (1 - maxlirunback / maxlirunbackYZ) * \
                         yllist[5] + (ordernum / ordernumYZ) * yllist[6] + (1 - maxPreloss / maxPrelossYZ) * yllist[7] + \
                         (1 - fluctions / fluctionsYZ) * yllist[8] + (avgRev / avgRevYZ) * yllist[9] + (
                                 weekProfitMoney / weekProfitMoneyYZ) * yllist[10] + (
                                 mouthProfitMoney / mouthProfitMoneyYZ) * yllist[11] + \
                         (1 - shunshou / shunshouYZ) * yllist[12] + (nigong / nigongYZ) * yllist[13]
                ylrankdtl = '盈利:' + str(
                    round((totalprofit / totalprofitYZ) * yllist[0], 2)) + ' ' + '盈利因子:' + str(
                    round((profitFactor / profitFactorYZ) * yllist[1], 2)) + ' ' + '胜率:' + str(
                    round((winrate / winrateYZ) * yllist[2], 2)) + ' ' + \
                            '本金收益率:' + str(
                    round((benjinProfitRate / benjinProfitRateYZ) * yllist[3], 2)) + ' ' + '本金回撤率:' + str(
                    round((1 - maxbenjinback / maxbenjinbackYZ) * yllist[4], 2)) + ' ' + '利润回撤率:' + str(
                    round((1 - maxlirunback / maxlirunbackYZ) * yllist[5], 2)) + ' ' + \
                            '交易单量:' + str(
                    round((ordernum / ordernumYZ) * yllist[6], 2)) + ' ' + '最大结余亏损:' + str(
                    round((1 - maxPreloss / maxPrelossYZ) * yllist[7], 2)) + ' ' + '波动率:' + str(
                    round((1 - fluctions / fluctionsYZ) * yllist[8], 2)) + ' ' + \
                            '平均盈利:' + str(round((avgRev / avgRevYZ) * yllist[9], 2)) + ' ' + '周盈利能力:' + str(
                    round((weekProfitMoney / weekProfitMoneyYZ) * yllist[10], 2)) + ' ' + '月盈利能力:' + str(
                    round((mouthProfitMoney / mouthProfitMoneyYZ) * yllist[11], 2)) + ' ' + \
                            '顺守:' + str(round((1 - shunshou / shunshouYZ) * yllist[12], 2)) + ' ' + '逆功:' + str(
                    round((nigong / nigongYZ) * yllist[13], 2))

                bsrank = (totalprofit / totalprofitYZ) * bslist[0] + (profitFactor / profitFactorYZ) * bslist[1] + (
                        winrate / winrateYZ) * bslist[2] + (benjinProfitRate / benjinProfitRateYZ) * bslist[3] + \
                         (1 - maxbenjinback / maxbenjinbackYZ) * bslist[4] + (1 - maxlirunback / maxlirunbackYZ) * \
                         bslist[5] + (ordernum / ordernumYZ) * bslist[6] + (1 - maxPreloss / maxPrelossYZ) * bslist[7] + \
                         (1 - fluctions / fluctionsYZ) * bslist[8] + (avgRev / avgRevYZ) * bslist[9] + (
                                 weekProfitMoney / weekProfitMoneyYZ) * bslist[10] + (
                                 mouthProfitMoney / mouthProfitMoneyYZ) * bslist[11] + \
                         (1 - shunshou / shunshouYZ) * bslist[12] + (nigong / nigongYZ) * bslist[13]
                bsrankdtl = '盈利:' + str(
                    round((totalprofit / totalprofitYZ) * bslist[0], 2)) + ' ' + '盈利因子:' + str(
                    round((profitFactor / profitFactorYZ) * bslist[1], 2)) + ' ' + '胜率:' + str(
                    round((winrate / winrateYZ) * bslist[2], 2)) + ' ' + \
                            '本金收益率:' + str(
                    round((benjinProfitRate / benjinProfitRateYZ) * bslist[3], 2)) + ' ' + '本金回撤率:' + str(
                    round((1 - maxbenjinback / maxbenjinbackYZ) * bslist[4], 2)) + ' ' + '利润回撤率:' + str(
                    round((1 - maxlirunback / maxlirunbackYZ) * bslist[5], 2)) + ' ' + \
                            '交易单量:' + str(
                    round((ordernum / ordernumYZ) * bslist[6], 2)) + ' ' + '最大结余亏损:' + str(
                    round((1 - maxPreloss / maxPrelossYZ) * bslist[7], 2)) + ' ' + '波动率:' + str(
                    round((1 - fluctions / fluctionsYZ) * bslist[8], 2)) + ' ' + \
                            '平均盈利:' + str(round((avgRev / avgRevYZ) * bslist[9], 2)) + ' ' + '周盈利能力:' + str(
                    round((weekProfitMoney / weekProfitMoneyYZ) * bslist[10], 2)) + ' ' + '月盈利能力:' + str(
                    round((mouthProfitMoney / mouthProfitMoneyYZ) * bslist[11], 2)) + ' ' + \
                            '顺守:' + str(round((1 - shunshou / shunshouYZ) * bslist[12], 2)) + ' ' + '逆功:' + str(
                    round((nigong / nigongYZ) * bslist[13], 2))

                jcrank = (totalprofit / totalprofitYZ) * jclist[0] + (profitFactor / profitFactorYZ) * jclist[1] + (
                        winrate / winrateYZ) * jclist[2] + (benjinProfitRate / benjinProfitRateYZ) * jclist[3] + \
                         (1 - maxbenjinback / maxbenjinbackYZ) * jclist[4] + (1 - maxlirunback / maxlirunbackYZ) * \
                         jclist[5] + (ordernum / ordernumYZ) * jclist[6] + (1 - maxPreloss / maxPrelossYZ) * jclist[7] + \
                         (1 - fluctions / fluctionsYZ) * jclist[8] + (avgRev / avgRevYZ) * jclist[9] + (
                                 weekProfitMoney / weekProfitMoneyYZ) * jclist[10] + (
                                 mouthProfitMoney / mouthProfitMoneyYZ) * jclist[11] + \
                         (1 - shunshou / shunshouYZ) * jclist[12] + (nigong / nigongYZ) * jclist[13]
                jcrankdtl = '盈利:' + str(
                    round((totalprofit / totalprofitYZ) * jclist[0], 2)) + ' ' + '盈利因子:' + str(
                    round((profitFactor / profitFactorYZ) * jclist[1], 2)) + ' ' + '胜率:' + str(
                    round((winrate / winrateYZ) * jclist[2], 2)) + ' ' + \
                            '本金收益率:' + str(
                    round((benjinProfitRate / benjinProfitRateYZ) * jclist[3], 2)) + ' ' + '本金回撤率:' + str(
                    round((1 - maxbenjinback / maxbenjinbackYZ) * jclist[4], 2)) + ' ' + '利润回撤率:' + str(
                    round((1 - maxlirunback / maxlirunbackYZ) * jclist[5], 2)) + ' ' + \
                            '交易单量:' + str(
                    round((ordernum / ordernumYZ) * jclist[6], 2)) + ' ' + '最大结余亏损:' + str(
                    round((1 - maxPreloss / maxPrelossYZ) * jclist[7], 2)) + ' ' + '波动率:' + str(
                    round((1 - fluctions / fluctionsYZ) * jclist[8], 2)) + ' ' + \
                            '平均盈利:' + str(round((avgRev / avgRevYZ) * jclist[9], 2)) + ' ' + '周盈利能力:' + str(
                    round((weekProfitMoney / weekProfitMoneyYZ) * jclist[10], 2)) + ' ' + '月盈利能力:' + str(
                    round((mouthProfitMoney / mouthProfitMoneyYZ) * jclist[11], 2)) + ' ' + \
                            '顺守:' + str(round((1 - shunshou / shunshouYZ) * jclist[12], 2)) + ' ' + '逆功:' + str(
                    round((nigong / nigongYZ) * jclist[13], 2))

                addOrUpdateDict = {'reportname': file,
                                   'reporttime': getHtmlVar(file_data, 'reportTime'),
                                   'symbol': getHtmlVar(file_data, 'symbol'),
                                   'company': getHtmlVar(file_data, 'company'),
                                   'currency': getHtmlVar(file_data, 'currency'),
                                   'benjin': getHtmlVar(file_data, 'benjin'),
                                   'leverage': getHtmlVar(file_data, 'leverage'),
                                   'timeframe': getHtmlVar(file_data, 'timeframe'),
                                   'symbolnum': getHtmlVar(file_data, 'symbolnum'),
                                   'passtavg': getHtmlVar(file_data, 'passtavg'),
                                   'passtmax': getHtmlVar(file_data, 'passtmax'),
                                   'passtmin': getHtmlVar(file_data, 'passtmin'),
                                   'totalprofit': getHtmlVar(file_data, 'totalprofit'),
                                   'maxPreloss': getHtmlVar(file_data, 'maxPreloss'),
                                   'maxnetloss': getHtmlVar(file_data, 'maxnetloss'),
                                   'profit_total': getHtmlVar(file_data, 'profit_total'),
                                   'loss_total': getHtmlVar(file_data, 'loss_total'),
                                   'maxseedin': getHtmlVar(file_data, 'maxseedin'),
                                   'profitFactor': getHtmlVar(file_data, 'profitFactor'),
                                   'sharpe': wAmdataDict['sharpe'],
                                   'fluctions': getHtmlVar(file_data, 'fluctions'),
                                   'winrate': getHtmlVar(file_data, 'winrate'),
                                   'benjinProfitRate': getHtmlVar(file_data, 'benjinProfitRate'),
                                   'ordernum': getHtmlVar(file_data, 'ordernum'),
                                   'buynum': getHtmlVar(file_data, 'buynum'),
                                   'sellnum': getHtmlVar(file_data, 'sellnum'),
                                   'tpnum': getHtmlVar(file_data, 'tpnum'),
                                   'slnum': getHtmlVar(file_data, 'slnum'),
                                   'avgRev': getHtmlVar(file_data, 'avgRev'),
                                   'minRev': getHtmlVar(file_data, 'minRev'),
                                   'maxRev': getHtmlVar(file_data, 'maxRev'),
                                   'maxfotp': getHtmlVar(file_data, 'maxfotp'),
                                   'avgfotp': getHtmlVar(file_data, 'avgfotp'),
                                   'maxfosl': getHtmlVar(file_data, 'maxfosl'),
                                   'avgfosl': getHtmlVar(file_data, 'avgfosl'),
                                   'maxbenjinback': getHtmlVar(file_data, 'maxbenjinback'),
                                   'maxlirunback': getHtmlVar(file_data, 'maxlirunback'),
                                   'continuLossNum': getHtmlVar(file_data, 'continuLossNum'),
                                   'continuProfitNum': getHtmlVar(file_data, 'continuProfitNum'),
                                   'continuLossMoney': getHtmlVar(file_data, 'continuLossMoney'),
                                   'continuProfitMoney': getHtmlVar(file_data, 'continuProfitMoney'),
                                   'shunshou': getHtmlVar(file_data, 'shunshou'),
                                   'nigong': getHtmlVar(file_data, 'nigong'),
                                   'loss3': getHtmlVar(file_data, 'loss3'),
                                   'loss5': getHtmlVar(file_data, 'loss5'),
                                   'weekNum': wAmdataDict['weekNum'],
                                   'weekProfitMoney': wAmdataDict['weekProfitMoney'],
                                   'weekProfitNum': wAmdataDict['weekProfitNum'],
                                   'weekProfitrate': wAmdataDict['weekProfitrate'],
                                   'monthNum': wAmdataDict['monthNum'],
                                   'mouthProfitMoney': wAmdataDict['mouthProfitMoney'],
                                   'mouthProfitNum': wAmdataDict['mouthProfitNum'],
                                   'mouthProfitrate': wAmdataDict['mouthProfitrate'],
                                   'spread': getHtmlVar(file_data, 'spread'),
                                   'notes': getHtmlVar(file_data, 'notes'),
                                   'others': '',
                                   'ylrank': round(ylrank, 2),
                                   'ylrankdtl': ylrankdtl,
                                   'bsrankdtl': bsrankdtl,
                                   'jcrankdtl': jcrankdtl,
                                   'bsrank': round(bsrank, 2),
                                   'jcrank': round(jcrank, 2)
                                   }

                reportid = mergeIntoRpt(addOrUpdateDict)
                orderStr = getHtmlVar(file_data, 'table1date')[:-1].replace("'", "\"")
                orderStr = orderStr.replace("{", "{\"reportname\":\"" + file + "\",\"reporttime\":\"" + str(
                    getHtmlVar(file_data, 'reportTime')) + "\"," + "\"" + "reportid" + "\":\"" + str(reportid) + "\",")
                orderArr = json.loads('[' + orderStr + ']')

                for order in orderArr:
                    intoRptOrd(order)

                # 将文件转移至upload
                # 确保源文件存在
                if not os.path.exists(source_file_path):
                    print(f"Error: Source file '{source_file_path}' does not exist.")
                    return
                else:
                    # 删除文件
                    try:
                        os.remove(source_file_path)
                        print(f"File '{source_file_path}' deleted successfully.")
                    except Exception as e:
                        print(f"Error deleting file '{source_file_path}': {e}")
            # 释放锁
            # upload_lock.release()
            # else:
            #     return HttpResponse('其他用户正在上传，请稍等!')
        else:

            #  ------------------------------------------------------------------------
            if not file.name.endswith('.html'):
                return HttpResponse('我们暂时只维护html文件!')

            # 读取单个文件内容
            file_data = file.read()
            file_path = os.path.join(desktop_path, 'upload', file.name)

            with open(file_path, 'wb+') as f:
                for chunk in file.chunks():
                    f.write(chunk)

            fileurl = 'file:///' + file_path
            wAmdataDict = getWeekAndMonthData(fileurl)

            addOrUpdateDict = {'reportname': file.name,
                               'reporttime': getHtmlVar(file_data.decode(), 'reportTime'),
                               'symbol': getHtmlVar(file_data.decode(), 'symbol'),
                               'company': getHtmlVar(file_data.decode(), 'company'),
                               'currency': getHtmlVar(file_data.decode(), 'currency'),
                               'benjin': getHtmlVar(file_data.decode(), 'benjin'),
                               'leverage': getHtmlVar(file_data.decode(), 'leverage'),
                               'timeframe': getHtmlVar(file_data.decode(), 'timeframe'),
                               'symbolnum': getHtmlVar(file_data.decode(), 'symbolnum'),
                               'passtavg': getHtmlVar(file_data.decode(), 'passtavg'),
                               'passtmax': getHtmlVar(file_data.decode(), 'passtmax'),
                               'passtmin': getHtmlVar(file_data.decode(), 'passtmin'),
                               'totalprofit': getHtmlVar(file_data.decode(), 'totalprofit'),
                               'maxPreloss': getHtmlVar(file_data.decode(), 'maxPreloss'),
                               'maxnetloss': getHtmlVar(file_data.decode(), 'maxnetloss'),
                               'profit_total': getHtmlVar(file_data.decode(), 'profit_total'),
                               'loss_total': getHtmlVar(file_data.decode(), 'loss_total'),
                               'maxseedin': getHtmlVar(file_data.decode(), 'maxseedin'),
                               'profitFactor': getHtmlVar(file_data.decode(), 'profitFactor'),
                               'sharpe': getHtmlVar(file_data.decode(), 'sharpe'),
                               'fluctions': getHtmlVar(file_data.decode(), 'fluctions'),
                               'winrate': getHtmlVar(file_data.decode(), 'winrate'),
                               'benjinProfitRate': getHtmlVar(file_data.decode(), 'benjinProfitRate'),
                               'ordernum': getHtmlVar(file_data.decode(), 'ordernum'),
                               'buynum': getHtmlVar(file_data.decode(), 'buynum'),
                               'sellnum': getHtmlVar(file_data.decode(), 'sellnum'),
                               'tpnum': getHtmlVar(file_data.decode(), 'tpnum'),
                               'slnum': getHtmlVar(file_data.decode(), 'slnum'),
                               'avgRev': getHtmlVar(file_data.decode(), 'avgRev'),
                               'minRev': getHtmlVar(file_data.decode(), 'minRev'),
                               'maxRev': getHtmlVar(file_data.decode(), 'maxRev'),
                               'maxfotp': getHtmlVar(file_data.decode(), 'maxfotp'),
                               'avgfotp': getHtmlVar(file_data.decode(), 'avgfotp'),
                               'maxfosl': getHtmlVar(file_data.decode(), 'maxfosl'),
                               'avgfosl': getHtmlVar(file_data.decode(), 'avgfosl'),
                               'maxbenjinback': getHtmlVar(file_data.decode(), 'maxbenjinback'),
                               'maxlirunback': getHtmlVar(file_data.decode(), 'maxlirunback'),
                               'continuLossNum': getHtmlVar(file_data.decode(), 'continuLossNum'),
                               'continuProfitNum': getHtmlVar(file_data.decode(), 'continuProfitNum'),
                               'continuLossMoney': getHtmlVar(file_data.decode(), 'continuLossMoney'),
                               'continuProfitMoney': getHtmlVar(file_data.decode(), 'continuProfitMoney'),
                               'shunshou': getHtmlVar(file_data.decode(), 'shunshou'),
                               'nigong': getHtmlVar(file_data.decode(), 'nigong'),
                               'loss3': getHtmlVar(file_data.decode(), 'loss3'),
                               'loss5': getHtmlVar(file_data.decode(), 'loss5'),
                               'weekNum': wAmdataDict['weekNum'],
                               'weekProfitMoney': wAmdataDict['weekNum'],
                               'weekProfitNum': wAmdataDict['weekProfitNum'],
                               'weekProfitrate': wAmdataDict['weekProfitrate'],
                               'monthNum': wAmdataDict['monthNum'],
                               'mouthProfitMoney': wAmdataDict['mouthProfitMoney'],
                               'mouthProfitNum': wAmdataDict['mouthProfitNum'],
                               'mouthProfitrate': wAmdataDict['mouthProfitrate'],
                               'spread': getHtmlVar(file_data.decode(), 'spread'),
                               'notes': getHtmlVar(file_data.decode(), 'notes'),
                               'others': ''
                               }
            reportid = mergeIntoRpt(addOrUpdateDict)
            orderStr = getHtmlVar(file_data.decode(), 'table1date')[:-1].replace("'", "\"")
            orderStr = orderStr.replace("{", "{\"reportname\":\"" + file.name + "\",\"reporttime\":\"" + getHtmlVar(
                file_data.decode(), 'reportTime') + "\"," + "\"" + "reportid" + "\":\"" + str(reportid) + "\",")
            orderArr = json.loads('[' + orderStr + ']')

            for order in orderArr:
                intoRptOrd(order)
            return HttpResponse('文件上传成功!')
    # except Exception as e:
    #     return HttpResponse("他人正在上传，请稍后再试！")

    return render(request, 'upload.html')


# 修改后的rptUpload方法，不再接收request作为参数
def rptUpload(file_data, file_name):
    desktop_path = os.path.expanduser(r"C:\Users\Administrator\Desktop")

    # 创建临时文件夹tmp
    tmp_path = os.path.join(desktop_path, 'tmp')

    source_folder = tmp_path
    source_file_path = os.path.join(source_folder, file_name)

    fileurl = 'file:///' + source_file_path
    wAmdataDict = getWeekAndMonthData(fileurl)

    # 得到评分

    # 各个指标真值
    totalprofit = float(getHtmlVar(file_data, 'totalprofit'))
    profitFactor = float(getHtmlVar(file_data, 'profitFactor'))
    winrate = float(getHtmlVar(file_data, 'winrate'))
    benjinProfitRate = float(getHtmlVar(file_data, 'benjinProfitRate'))
    maxbenjinback = float(getHtmlVar(file_data, 'maxbenjinback'))
    maxlirunback = float(getHtmlVar(file_data, 'maxlirunback'))
    ordernum = float(getHtmlVar(file_data, 'ordernum'))
    maxPreloss = float(getHtmlVar(file_data, 'maxPreloss'))
    fluctions = float(getHtmlVar(file_data, 'fluctions'))
    avgRev = float(getHtmlVar(file_data, 'avgRev'))
    weekProfitMoney = float(wAmdataDict['weekProfitMoney'])
    mouthProfitMoney = float(wAmdataDict['mouthProfitMoney'])
    shunshou = float(getHtmlVar(file_data, 'shunshou'))  # 越小越好
    nigong = float(getHtmlVar(file_data, 'nigong'))  # 越大越好

    ylrank = (totalprofit / totalprofitYZ) * yllist[0] + (profitFactor / profitFactorYZ) * yllist[1] + (
            winrate / winrateYZ) * yllist[2] + (benjinProfitRate / benjinProfitRateYZ) * yllist[3] + \
             (1 - maxbenjinback / maxbenjinbackYZ) * yllist[4] + (1 - maxlirunback / maxlirunbackYZ) * yllist[
                 5] + (ordernum / ordernumYZ) * yllist[6] + (1 - maxPreloss / maxPrelossYZ) * yllist[7] + \
             (1 - fluctions / fluctionsYZ) * yllist[8] + (avgRev / avgRevYZ) * yllist[9] + (
                     weekProfitMoney / weekProfitMoneyYZ) * yllist[10] + (
                     mouthProfitMoney / mouthProfitMoneyYZ) * yllist[11] + \
             (1 - shunshou / shunshouYZ) * yllist[12] + (nigong / nigongYZ) * yllist[13]
    ylrankdtl = '盈利:' + str(round((totalprofit / totalprofitYZ) * yllist[0], 2)) + ' ' + '盈利因子:' + str(
        round((profitFactor / profitFactorYZ) * yllist[1], 2)) + ' ' + '胜率:' + str(
        round((winrate / winrateYZ) * yllist[2], 2)) + ' ' + \
                '本金收益率:' + str(
        round((benjinProfitRate / benjinProfitRateYZ) * yllist[3], 2)) + ' ' + '本金回撤率:' + str(
        round((1 - maxbenjinback / maxbenjinbackYZ) * yllist[4], 2)) + ' ' + '利润回撤率:' + str(
        round((1 - maxlirunback / maxlirunbackYZ) * yllist[5], 2)) + ' ' + \
                '交易单量:' + str(round((ordernum / ordernumYZ) * yllist[6], 2)) + ' ' + '最大结余亏损:' + str(
        round((1 - maxPreloss / maxPrelossYZ) * yllist[7], 2)) + ' ' + '波动率:' + str(
        round((1 - fluctions / fluctionsYZ) * yllist[8], 2)) + ' ' + \
                '平均盈利:' + str(round((avgRev / avgRevYZ) * yllist[9], 2)) + ' ' + '周盈利能力:' + str(
        round((weekProfitMoney / weekProfitMoneyYZ) * yllist[10], 2)) + ' ' + '月盈利能力:' + str(
        round((mouthProfitMoney / mouthProfitMoneyYZ) * yllist[11], 2)) + ' ' + \
                '顺守:' + str(round((1 - shunshou / shunshouYZ) * yllist[12], 2)) + ' ' + '逆功:' + str(
        round((nigong / nigongYZ) * yllist[13], 2))

    bsrank = (totalprofit / totalprofitYZ) * bslist[0] + (profitFactor / profitFactorYZ) * bslist[1] + (
            winrate / winrateYZ) * bslist[2] + (benjinProfitRate / benjinProfitRateYZ) * bslist[3] + \
             (1 - maxbenjinback / maxbenjinbackYZ) * bslist[4] + (1 - maxlirunback / maxlirunbackYZ) * bslist[
                 5] + (ordernum / ordernumYZ) * bslist[6] + (1 - maxPreloss / maxPrelossYZ) * bslist[7] + \
             (1 - fluctions / fluctionsYZ) * bslist[8] + (avgRev / avgRevYZ) * bslist[9] + (
                     weekProfitMoney / weekProfitMoneyYZ) * bslist[10] + (
                     mouthProfitMoney / mouthProfitMoneyYZ) * bslist[11] + \
             (1 - shunshou / shunshouYZ) * bslist[12] + (nigong / nigongYZ) * bslist[13]
    bsrankdtl = '盈利:' + str(round((totalprofit / totalprofitYZ) * bslist[0], 2)) + ' ' + '盈利因子:' + str(
        round((profitFactor / profitFactorYZ) * bslist[1], 2)) + ' ' + '胜率:' + str(
        round((winrate / winrateYZ) * bslist[2], 2)) + ' ' + \
                '本金收益率:' + str(
        round((benjinProfitRate / benjinProfitRateYZ) * bslist[3], 2)) + ' ' + '本金回撤率:' + str(
        round((1 - maxbenjinback / maxbenjinbackYZ) * bslist[4], 2)) + ' ' + '利润回撤率:' + str(
        round((1 - maxlirunback / maxlirunbackYZ) * bslist[5], 2)) + ' ' + \
                '交易单量:' + str(round((ordernum / ordernumYZ) * bslist[6], 2)) + ' ' + '最大结余亏损:' + str(
        round((1 - maxPreloss / maxPrelossYZ) * bslist[7], 2)) + ' ' + '波动率:' + str(
        round((1 - fluctions / fluctionsYZ) * bslist[8], 2)) + ' ' + \
                '平均盈利:' + str(round((avgRev / avgRevYZ) * bslist[9], 2)) + ' ' + '周盈利能力:' + str(
        round((weekProfitMoney / weekProfitMoneyYZ) * bslist[10], 2)) + ' ' + '月盈利能力:' + str(
        round((mouthProfitMoney / mouthProfitMoneyYZ) * bslist[11], 2)) + ' ' + \
                '顺守:' + str(round((1 - shunshou / shunshouYZ) * bslist[12], 2)) + ' ' + '逆功:' + str(
        round((nigong / nigongYZ) * bslist[13], 2))

    jcrank = (totalprofit / totalprofitYZ) * jclist[0] + (profitFactor / profitFactorYZ) * jclist[1] + (
            winrate / winrateYZ) * jclist[2] + (benjinProfitRate / benjinProfitRateYZ) * jclist[3] + \
             (1 - maxbenjinback / maxbenjinbackYZ) * jclist[4] + (1 - maxlirunback / maxlirunbackYZ) * jclist[
                 5] + (ordernum / ordernumYZ) * jclist[6] + (1 - maxPreloss / maxPrelossYZ) * jclist[7] + \
             (1 - fluctions / fluctionsYZ) * jclist[8] + (avgRev / avgRevYZ) * jclist[9] + (
                     weekProfitMoney / weekProfitMoneyYZ) * jclist[10] + (
                     mouthProfitMoney / mouthProfitMoneyYZ) * jclist[11] + \
             (1 - shunshou / shunshouYZ) * jclist[12] + (nigong / nigongYZ) * jclist[13]
    jcrankdtl = '盈利:' + str(round((totalprofit / totalprofitYZ) * jclist[0], 2)) + ' ' + '盈利因子:' + str(
        round((profitFactor / profitFactorYZ) * jclist[1], 2)) + ' ' + '胜率:' + str(
        round((winrate / winrateYZ) * jclist[2], 2)) + ' ' + \
                '本金收益率:' + str(
        round((benjinProfitRate / benjinProfitRateYZ) * jclist[3], 2)) + ' ' + '本金回撤率:' + str(
        round((1 - maxbenjinback / maxbenjinbackYZ) * jclist[4], 2)) + ' ' + '利润回撤率:' + str(
        round((1 - maxlirunback / maxlirunbackYZ) * jclist[5], 2)) + ' ' + \
                '交易单量:' + str(round((ordernum / ordernumYZ) * jclist[6], 2)) + ' ' + '最大结余亏损:' + str(
        round((1 - maxPreloss / maxPrelossYZ) * jclist[7], 2)) + ' ' + '波动率:' + str(
        round((1 - fluctions / fluctionsYZ) * jclist[8], 2)) + ' ' + \
                '平均盈利:' + str(round((avgRev / avgRevYZ) * jclist[9], 2)) + ' ' + '周盈利能力:' + str(
        round((weekProfitMoney / weekProfitMoneyYZ) * jclist[10], 2)) + ' ' + '月盈利能力:' + str(
        round((mouthProfitMoney / mouthProfitMoneyYZ) * jclist[11], 2)) + ' ' + \
                '顺守:' + str(round((1 - shunshou / shunshouYZ) * jclist[12], 2)) + ' ' + '逆功:' + str(
        round((nigong / nigongYZ) * jclist[13], 2))

    addOrUpdateDict = {'reportname': file_name,
                       'reporttime': getHtmlVar(file_data, 'reportTime'),
                       'symbol': getHtmlVar(file_data, 'symbol'),
                       'company': getHtmlVar(file_data, 'company'),
                       'currency': getHtmlVar(file_data, 'currency'),
                       'benjin': getHtmlVar(file_data, 'benjin'),
                       'leverage': getHtmlVar(file_data, 'leverage'),
                       'timeframe': getHtmlVar(file_data, 'timeframe'),
                       'symbolnum': getHtmlVar(file_data, 'symbolnum'),
                       'passtavg': getHtmlVar(file_data, 'passtavg'),
                       'passtmax': getHtmlVar(file_data, 'passtmax'),
                       'passtmin': getHtmlVar(file_data, 'passtmin'),
                       'totalprofit': getHtmlVar(file_data, 'totalprofit'),
                       'maxPreloss': getHtmlVar(file_data, 'maxPreloss'),
                       'maxnetloss': getHtmlVar(file_data, 'maxnetloss'),
                       'profit_total': getHtmlVar(file_data, 'profit_total'),
                       'loss_total': getHtmlVar(file_data, 'loss_total'),
                       'maxseedin': getHtmlVar(file_data, 'maxseedin'),
                       'profitFactor': getHtmlVar(file_data, 'profitFactor'),
                       'sharpe': wAmdataDict['sharpe'],
                       'fluctions': getHtmlVar(file_data, 'fluctions'),
                       'winrate': getHtmlVar(file_data, 'winrate'),
                       'benjinProfitRate': getHtmlVar(file_data, 'benjinProfitRate'),
                       'ordernum': getHtmlVar(file_data, 'ordernum'),
                       'buynum': getHtmlVar(file_data, 'buynum'),
                       'sellnum': getHtmlVar(file_data, 'sellnum'),
                       'tpnum': getHtmlVar(file_data, 'tpnum'),
                       'slnum': getHtmlVar(file_data, 'slnum'),
                       'avgRev': getHtmlVar(file_data, 'avgRev'),
                       'minRev': getHtmlVar(file_data, 'minRev'),
                       'maxRev': getHtmlVar(file_data, 'maxRev'),
                       'maxfotp': getHtmlVar(file_data, 'maxfotp'),
                       'avgfotp': getHtmlVar(file_data, 'avgfotp'),
                       'maxfosl': getHtmlVar(file_data, 'maxfosl'),
                       'avgfosl': getHtmlVar(file_data, 'avgfosl'),
                       'maxbenjinback': getHtmlVar(file_data, 'maxbenjinback'),
                       'maxlirunback': getHtmlVar(file_data, 'maxlirunback'),
                       'continuLossNum': getHtmlVar(file_data, 'continuLossNum'),
                       'continuProfitNum': getHtmlVar(file_data, 'continuProfitNum'),
                       'continuLossMoney': getHtmlVar(file_data, 'continuLossMoney'),
                       'continuProfitMoney': getHtmlVar(file_data, 'continuProfitMoney'),
                       'shunshou': getHtmlVar(file_data, 'shunshou'),
                       'nigong': getHtmlVar(file_data, 'nigong'),
                       'loss3': getHtmlVar(file_data, 'loss3'),
                       'loss5': getHtmlVar(file_data, 'loss5'),
                       'weekNum': wAmdataDict['weekNum'],
                       'weekProfitMoney': wAmdataDict['weekProfitMoney'],
                       'weekProfitNum': wAmdataDict['weekProfitNum'],
                       'weekProfitrate': wAmdataDict['weekProfitrate'],
                       'monthNum': wAmdataDict['monthNum'],
                       'mouthProfitMoney': wAmdataDict['mouthProfitMoney'],
                       'mouthProfitNum': wAmdataDict['mouthProfitNum'],
                       'mouthProfitrate': wAmdataDict['mouthProfitrate'],
                       'spread': getHtmlVar(file_data, 'spread'),
                       'notes': getHtmlVar(file_data, 'notes'),
                       'others': '',
                       'ylrank': round(ylrank, 2),
                       'ylrankdtl': ylrankdtl,
                       'bsrankdtl': bsrankdtl,
                       'jcrankdtl': jcrankdtl,
                       'bsrank': round(bsrank, 2),
                       'jcrank': round(jcrank, 2)
                       }
    reportid = mergeIntoRpt(addOrUpdateDict)
    orderStr = getHtmlVar(file_data, 'table1date')[:-1].replace("'", "\"")
    orderStr = orderStr.replace("{", "{\"reportname\":\"" + file_name + "\",\"reporttime\":\"" + str(
        getHtmlVar(file_data, 'reportTime')) + "\"," + "\"" + "reportid" + "\":\"" + str(reportid) + "\",")
    orderArr = json.loads('[' + orderStr + ']')

    for order in orderArr:
        intoRptOrd(order)

    # 确保源文件存在
    # if not os.path.exists(source_file_path):
    #     print(f"Error: Source file '{source_file_path}' does not exist.")
    #     return
    # else:
    #     # 删除文件
    #     try:
    #         os.remove(source_file_path)
    #         print(f"File '{source_file_path}' deleted successfully.")
    #     except Exception as e:
    #         print(f"Error deleting file '{source_file_path}': {e}")
    return HttpResponse('文件上传成功!')


def handle_upload(upload_info):
    file_data, file_name = upload_info
    return rptUpload(file_data, file_name)


@csrf_exempt
def upload_file(request):
    if request.method == 'POST':
        # 获取上传的文件列表
        uploaded_files = request.FILES.getlist('file')

        if not uploaded_files:
            response_data = {
                'message': 'No files uploaded.',
            }
            return JsonResponse(response_data, status=400)

        try:
            # 创建临时文件夹tmp
            desktop_path = os.path.expanduser(r"C:\Users\Administrator\Desktop")
            tmp_path = os.path.join(desktop_path, 'tmp')
            os.makedirs(tmp_path, exist_ok=True)  # 如果tmp文件夹已经存在则不报错，没有则创建

            upload_info_list = []
            for uploaded_file in uploaded_files:
                # 检查上传的文件是否为zip类型，并将它放到tmp文件夹里面
                if uploaded_file.content_type == 'application/zip' or uploaded_file.name.endswith('.zip'):
                    # 创建一个ZipFile对象
                    with zipfile.ZipFile(uploaded_file, 'r') as zip_ref:
                        # 解压缩文件到目标路径
                        zip_ref.extractall(tmp_path)

                    # 获取源文件夹中的所有文件列表
                    files = os.listdir(tmp_path)
                    for file in files:
                        source_file_path = os.path.join(tmp_path, file)
                        # 读取文件内容
                        with open(source_file_path, 'r', encoding='utf-8') as source_file:
                            file_data = source_file.read()

                        upload_info_list.append((file_data, file))

            # 使用ThreadPoolExecutor处理上传文件
            with concurrent.futures.ThreadPoolExecutor() as executor:
                results = executor.map(handle_upload, upload_info_list)

            # 处理上传完成后的逻辑（假设代码未变）
            # ...

            # 返回响应
            return HttpResponse('文件上传成功!')
        except Exception as e:
            # 处理上传文件失败的情况

            return HttpResponse('文件上传失败!')

    else:
        # 不是POST请求
        return HttpResponse('请求方法无效!')


@csrf_exempt
def openSourceRpt(request):
    try:
        if request.method == 'POST':
            sourceRptname = request.POST.get('sourceRptname')
            url = r"C:\Users\Administrator\Desktop\tmp"
            source_file_path = os.path.join(url, sourceRptname)
            with open(source_file_path, 'r', encoding='utf-8') as source_file:
                content = source_file.read()
            return HttpResponse(content, content_type="text/html")
    except Exception as e:
        print(e)
        error_message = '请求失败! ' + str(e)
        return HttpResponse(error_message)
