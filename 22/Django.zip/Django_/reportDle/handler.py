# 数据库级别的增删改查 全部放在这里
from django.db import connection

from reportDle.models import TestReportSummary, TestReportOrder
from django.db.models import Q

# 数据库级别的增删改查 全部放在这里
from reportDle.utils import convert_to_q_object


def selectRptSummary(paramsdict):
    symbol = paramsdict['symbol']  # 品种
    timeframe = paramsdict['timeframe']  # 交易周期
    timelimit = paramsdict['timelimit']  # 时间限制
    tunmo = paramsdict['tunmo']  # 吞没
    yingxian = paramsdict['yingxian']  # 影线
    atr = paramsdict['atr']  # ART
    shiti = paramsdict['shiti']  # 实体
    yingxianbi = paramsdict['yingxianbi']  # 影线比
    dak = paramsdict['dak']  # 大K
    muzi = paramsdict['muzi']  # 母子形态
    muzibi = paramsdict['muzibi']  # 母子比
    fanzhuan = paramsdict['fanzhuan']  # 反转形态
    pianyi = paramsdict['pianyi']  # 偏移
    zhiying = paramsdict['zhiying']  # 止盈
    zhisun = paramsdict['zhisun']  # 止损
    kdj = paramsdict['kdj']  # kdj
    shijian = paramsdict['shijian']  # 时间

    # -------------------------------------------------#
    totalprofit = paramsdict['totalprofit']  # 净盈利
    maxPreloss = paramsdict['maxPreloss']  # 最大结余亏损
    maxseedin = paramsdict['maxseedin']  # 最大入金加载
    profitFactor = paramsdict['profitFactor']  # 盈利因子
    winrate = paramsdict['winrate']  # 胜率
    benjinProfitRate = paramsdict['benjinProfitRate']  # 本金收益率
    maxbenjinback = paramsdict['maxbenjinback']  # 最大本金回撤
    maxlirunback = paramsdict['maxlirunback']  # 最大利润回撤
    avgRev = paramsdict['avgRev']  # 平均盈利
    ordernum = paramsdict['ordernum']  # 交易单量
    tpnum = paramsdict['tpnum']  # 盈利单量
    slnum = paramsdict['slnum']  # 亏损单量
    shunshou = paramsdict['shunshou']  # 顺守
    nigong = paramsdict['nigong']  # 逆功
    loss3 = paramsdict['loss3']  # 连续亏损3次的数目
    loss5 = paramsdict['loss5']  # 连续亏损5次的数目
    fluctions = paramsdict['fluctions']  # 波动率
    passtavg = paramsdict['passtavg']  # 平均持仓时间
    sharpe = paramsdict['sharpe']  # 夏普比率
    weekNum = paramsdict['weekNum']  # 周数
    weekProfitMoney = paramsdict['weekProfitMoney']  # 平均周盈利能力
    weekProfitNum = paramsdict['weekProfitNum']  # 平均周交易次数
    weekProfitrate = paramsdict['weekProfitrate']  # 平均周增长率
    monthNum = paramsdict['monthNum']  # 月数
    monthProfitMoney = paramsdict['monthProfitMoney']  # 平均月盈利能力
    monthProfitNum = paramsdict['monthProfitNum']  # 平均月交易次数
    monthProfitrate = paramsdict['monthProfitrate']  # 平均月增长率
    ylrank = paramsdict['ylrank']  # 盈利评分
    bsrank = paramsdict['bsrank']  # 保守评分
    jcrank = paramsdict['jcrank']  # 加仓评分

    # 构建空的 Q 对象
    q_obj = Q()

    # 根据条件动态添加 Q 对象
    if len(symbol) != 0:
        q_obj &= Q(reportname__contains=symbol)

    if len(timelimit) != 0:
        q_obj &= Q(reportname__contains=timelimit)

    if len(tunmo) != 0:
        q_obj &= Q(reportname__contains='吞没=' + tunmo)

    if len(yingxian) != 0:
        q_obj &= Q(reportname__contains='影线=' + yingxian)

    if len(atr) != 0:
        q_obj &= Q(reportname__contains='ATR=' + atr)

    if len(shiti) != 0:
        q_obj &= Q(reportname__contains='实体=' + shiti)

    if len(yingxianbi) != 0:
        q_obj &= Q(reportname__contains='影线比=' + yingxianbi)

    if len(dak) != 0:
        q_obj &= Q(reportname__contains='大K=' + dak)

    if len(muzi) != 0:
        q_obj &= Q(reportname__contains='母子=' + muzi)

    if len(muzibi) != 0:
        q_obj &= Q(reportname__contains='母子比=' + muzibi)

    if len(fanzhuan) != 0:
        q_obj &= Q(reportname__contains='反转=' + fanzhuan)

    if len(pianyi) != 0:
        q_obj &= Q(reportname__contains='偏移=' + pianyi)

    if len(zhiying) != 0:
        q_obj &= Q(reportname__contains='止盈=' + zhiying)

    if len(zhisun) != 0:
        q_obj &= Q(reportname__contains='止损=' + zhisun)

    if len(kdj) != 0:
        q_obj &= Q(reportname__contains='KDJ=' + kdj)

    if len(shijian) != 0:
        q_obj &= Q(reportname__contains=shijian)

    if len(timeframe) != 0:
        timeframe = timeframe.replace('x', 'timeframe')
        q_obj &= convert_to_q_object(timeframe)

    if len(totalprofit) != 0:
        totalprofit = totalprofit.replace('x', 'totalprofit')
        q_obj &= convert_to_q_object(totalprofit)

    if len(maxPreloss) != 0:
        maxPreloss = maxPreloss.replace('x', 'maxPreloss')
        q_obj &= convert_to_q_object(maxPreloss)

    if len(maxseedin) != 0:
        maxseedin = maxseedin.replace('x', 'maxseedin')
        q_obj &= convert_to_q_object(maxseedin)

    if len(profitFactor) != 0:
        profitFactor = profitFactor.replace('x', 'profitFactor')
        q_obj &= convert_to_q_object(profitFactor)

    if len(winrate) != 0:
        winrate = winrate.replace('x', 'winrate')
        q_obj &= convert_to_q_object(winrate)

    if len(benjinProfitRate) != 0:
        benjinProfitRate = benjinProfitRate.replace('x', 'benjinProfitRate')
        q_obj &= convert_to_q_object(benjinProfitRate)

    if len(maxbenjinback) != 0:
        maxbenjinback = maxbenjinback.replace('x', 'maxbenjinback')
        q_obj &= convert_to_q_object(maxbenjinback)

    if len(maxlirunback) != 0:
        maxlirunback = maxlirunback.replace('x', 'maxlirunback')
        q_obj &= convert_to_q_object(maxlirunback)

    if len(avgRev) != 0:
        avgRev = avgRev.replace('x', 'avgRev')
        q_obj &= convert_to_q_object(avgRev)

    if len(ordernum) != 0:
        ordernum = ordernum.replace('x', 'ordernum')
        q_obj &= convert_to_q_object(ordernum)

    if len(tpnum) != 0:
        tpnum = tpnum.replace('x', 'tpnum')
        q_obj &= convert_to_q_object(tpnum)

    if len(slnum) != 0:
        slnum = slnum.replace('x', 'slnum')
        q_obj &= convert_to_q_object(slnum)

    if len(shunshou) != 0:
        shunshou = shunshou.replace('x', 'shunshou')
        q_obj &= convert_to_q_object(shunshou)

    if len(nigong) != 0:
        nigong = nigong.replace('x', 'nigong')
        q_obj &= convert_to_q_object(nigong)

    if len(loss3) != 0:
        loss3 = loss3.replace('x', 'loss3')
        q_obj &= convert_to_q_object(loss3)

    if len(loss5) != 0:
        loss5 = loss5.replace('x', 'loss5')
        q_obj &= convert_to_q_object(loss5)

    if len(fluctions) != 0:
        fluctions = fluctions.replace('x', 'fluctions')
        q_obj &= convert_to_q_object(fluctions)

    if len(passtavg) != 0:
        passtavg = passtavg.replace('x', 'passtavg')
        q_obj &= convert_to_q_object(passtavg)

    if len(sharpe) != 0:
        sharpe = sharpe.replace('x', 'sharpe')
        q_obj &= convert_to_q_object(sharpe)

    if len(weekNum) != 0:
        weekNum = weekNum.replace('x', 'weekNum')
        q_obj &= convert_to_q_object(weekNum)

    if len(weekProfitMoney) != 0:
        weekProfitMoney = weekProfitMoney.replace('x', 'weekProfitMoney')
        q_obj &= convert_to_q_object(weekProfitMoney)

    if len(weekProfitNum) != 0:
        weekProfitNum = weekProfitNum.replace('x', 'weekProfitNum')
        q_obj &= convert_to_q_object(weekProfitNum)

    if len(weekProfitrate) != 0:
        weekProfitrate = weekProfitrate.replace('x', 'weekProfitrate')
        q_obj &= convert_to_q_object(weekProfitrate)

    if len(monthNum) != 0:
        monthNum = monthNum.replace('x', 'monthNum')
        q_obj &= convert_to_q_object(monthNum)

    if len(monthProfitMoney) != 0:
        monthProfitMoney = monthProfitMoney.replace('x', 'monthProfitMoney')
        q_obj &= convert_to_q_object(monthProfitMoney)

    if len(monthProfitNum) != 0:
        monthProfitNum = monthProfitNum.replace('x', 'monthProfitNum')
        q_obj &= convert_to_q_object(monthProfitNum)

    if len(monthProfitrate) != 0:
        monthProfitrate = monthProfitrate.replace('x', 'monthProfitrate')
        q_obj &= convert_to_q_object(monthProfitrate)

    if len(ylrank) != 0:
        ylrank = ylrank.replace('x', 'ylrank')
        q_obj &= convert_to_q_object(ylrank)

    if len(bsrank) != 0:
        bsrank = bsrank.replace('x', 'bsrank')
        q_obj &= convert_to_q_object(bsrank)

    if len(jcrank) != 0:
        jcrank = jcrank.replace('x', 'jcrank')
        q_obj &= convert_to_q_object(jcrank)

    filtered_objects = TestReportSummary.objects.filter(q_obj)

    return filtered_objects


# mergeInto报告摘要
def mergeIntoRpt(paramsdict):
    # 根据标题判断记录是否存在
    try:
        records = TestReportSummary.objects.filter(reportname=paramsdict['reportname'])
        count = len(records)
        if count == 0:
            # 记录不存在，进行新增操作
            TestReportSummary.objects.create(**paramsdict)
        else:
            TestReportSummary.objects.filter(reportname=paramsdict['reportname']).update(
                reporttime=paramsdict['reporttime'], symbol=paramsdict['symbol'], company=paramsdict['company'],
                currency=paramsdict['currency'],
                benjin=paramsdict['benjin'], leverage=paramsdict['leverage'], timeframe=paramsdict['timeframe'],
                symbolnum=paramsdict['symbolnum'],
                passtavg=paramsdict['passtavg'], passtmax=paramsdict['passtmax'], passtmin=paramsdict['passtmin'],
                totalprofit=paramsdict['totalprofit'],
                maxPreloss=paramsdict['maxPreloss'], maxnetloss=paramsdict['maxnetloss'],
                profit_total=paramsdict['profit_total'], loss_total=paramsdict['loss_total'],
                maxseedin=paramsdict['maxseedin'], profitFactor=paramsdict['profitFactor'], sharpe=paramsdict['sharpe'],
                fluctions=paramsdict['fluctions'],
                winrate=paramsdict['winrate'], benjinProfitRate=paramsdict['benjinProfitRate'],
                ordernum=paramsdict['ordernum'], buynum=paramsdict['buynum'],
                sellnum=paramsdict['sellnum'], tpnum=paramsdict['tpnum'], slnum=paramsdict['slnum'],
                avgRev=paramsdict['avgRev'], minRev=paramsdict['minRev'],
                maxRev=paramsdict['maxRev'], maxfotp=paramsdict['maxfotp'], avgfotp=paramsdict['avgfotp'],
                maxfosl=paramsdict['maxfosl'], avgfosl=paramsdict['avgfosl'],
                maxbenjinback=paramsdict['maxbenjinback'], maxlirunback=paramsdict['maxlirunback'],
                continuLossNum=paramsdict['continuLossNum'],
                continuProfitNum=paramsdict['continuProfitNum'], continuLossMoney=paramsdict['continuLossMoney'],
                continuProfitMoney=paramsdict['continuProfitMoney'],
                shunshou=paramsdict['shunshou'], nigong=paramsdict['nigong'], loss3=paramsdict['loss3'],
                loss5=paramsdict['loss5'], weekNum=paramsdict['weekNum'],
                weekProfitMoney=paramsdict['weekProfitMoney'], weekProfitNum=paramsdict['weekProfitNum'],
                weekProfitrate=paramsdict['weekProfitrate'],
                monthNum=paramsdict['monthNum'], mouthProfitMoney=paramsdict['mouthProfitMoney'],
                mouthProfitNum=paramsdict['mouthProfitNum'],
                mouthProfitrate=paramsdict['mouthProfitrate'], spread=paramsdict['spread'], notes=paramsdict['notes'],
                others=paramsdict['others'], ylrank=paramsdict['ylrank'], ylrankdtl=paramsdict['ylrankdtl'], bsrankdtl=paramsdict['bsrankdtl'],
                jcrankdtl=paramsdict['jcrankdtl'], bsrank=paramsdict['bsrank'], jcrank=paramsdict['jcrank'])
            # 如果更新，交易记录也要更新，所以先删除
            reportid = TestReportSummary.objects.filter(reportname=paramsdict['reportname']).values('id')[0]['id']
            TestReportOrder.objects.filter(Q(reportname=paramsdict['reportname']) & Q(reportid=reportid)).delete()
    except TestReportSummary.DoesNotExist:
        # 记录不存在，进行新增操作
        # TestReportSummary.objects.create(title="如来神掌", price=200, publish="功夫出版社", pub_date="2010-10-10")
        TestReportSummary.objects.create(**paramsdict)
    return TestReportSummary.objects.filter(reportname=paramsdict['reportname']).values('id')[0]['id']


def intoRptOrd(paramsdict):
    try:
        TestReportOrder.objects.create(**paramsdict)

    except TestReportOrder.DoesNotExist:
        TestReportOrder.objects.create(**paramsdict)


def queryOrdStopTandStoppById(reportid, reporttime):
    try:
        with connection.cursor() as cursor:
            year = reporttime[:4]
            sql_query = f"SELECT stopt,prebalance FROM test_report_order_{year} WHERE reportid = %s"
            params = [reportid]
            cursor.execute(sql_query, params)
            results = cursor.fetchall()
        return results
    except TestReportOrder.DoesNotExist:
        return None
