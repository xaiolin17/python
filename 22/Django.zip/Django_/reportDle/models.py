from datetime import datetime

from django.db import models


# Create your models here.
class TestReportSummary(models.Model):
    id = models.BigAutoField(primary_key=True, verbose_name='自增id')
    reporttime = models.DateTimeField(null=True, blank=True, verbose_name='创建时间')
    reportname = models.CharField(max_length=255, null=True, blank=True, verbose_name='报告名')
    symbol = models.CharField(max_length=255, null=True, blank=True, verbose_name='品种')
    company = models.CharField(max_length=255, null=True, blank=True, verbose_name='券商')
    currency = models.CharField(max_length=255, null=True, blank=True, verbose_name='货币')
    benjin = models.FloatField(null=True, blank=True, verbose_name='初始资金')
    leverage = models.CharField(max_length=255, null=True, blank=True, verbose_name='杠杆')
    timeframe = models.IntegerField(null=True, blank=True, verbose_name='周期')
    symbolnum = models.IntegerField(null=True, blank=True, verbose_name='交易品种数量')
    passtavg = models.CharField(max_length=255, null=True, blank=True, verbose_name='平均持仓时间')
    passtmax = models.CharField(max_length=255, null=True, blank=True, verbose_name='最大持仓时间')
    passtmin = models.CharField(max_length=255, null=True, blank=True, verbose_name='最小持仓时间')
    totalprofit = models.FloatField(null=True, blank=True, verbose_name='总盈利')
    maxPreloss = models.FloatField(null=True, blank=True, verbose_name='最大结余亏损')
    maxnetloss = models.FloatField(null=True, blank=True, verbose_name='最大净值亏损')
    profit_total = models.FloatField(null=True, blank=True, verbose_name='总盈利')
    loss_total = models.FloatField(null=True, blank=True, verbose_name='总亏损')
    maxseedin = models.FloatField(null=True, blank=True, verbose_name='最大入金加载')
    profitFactor = models.FloatField(null=True, blank=True, verbose_name='盈利因子')
    sharpe = models.FloatField(default=None, null=True, blank=True, verbose_name='夏普比率')
    fluctions = models.FloatField(null=True, blank=True, verbose_name='波动率')
    winrate = models.FloatField(null=True, blank=True, verbose_name='胜率')
    benjinProfitRate = models.FloatField(null=True, blank=True, verbose_name='本金收益率')
    ordernum = models.IntegerField(null=True, blank=True, verbose_name='交易单量')
    buynum = models.IntegerField(null=True, blank=True, verbose_name='买单')
    sellnum = models.IntegerField(null=True, blank=True, verbose_name='卖单')
    tpnum = models.IntegerField(null=True, blank=True, verbose_name='盈利单')
    slnum = models.IntegerField(null=True, blank=True, verbose_name='亏损单')
    avgRev = models.FloatField(null=True, blank=True, verbose_name='平均盈利')
    minRev = models.FloatField(null=True, blank=True, verbose_name='最差交易')
    maxRev = models.FloatField(null=True, blank=True, verbose_name='最好交易')
    maxfotp = models.FloatField(null=True, blank=True, verbose_name='最大浮盈')
    avgfotp = models.FloatField(null=True, blank=True, verbose_name='平均浮盈')
    maxfosl = models.FloatField(null=True, blank=True, verbose_name='最大浮亏')
    avgfosl = models.FloatField(null=True, blank=True, verbose_name='平均浮亏')
    maxbenjinback = models.FloatField(null=True, blank=True, verbose_name='最大本金回撤')
    maxlirunback = models.FloatField(null=True, blank=True, verbose_name='最大利润回撤')
    continuLossNum = models.IntegerField(null=True, blank=True, verbose_name='最大亏损次数')
    continuProfitNum = models.IntegerField(null=True, blank=True, verbose_name='最大盈利次数')
    continuLossMoney = models.FloatField(null=True, blank=True, verbose_name='最大连续亏损金额')
    continuProfitMoney = models.FloatField(null=True, blank=True, verbose_name='最大连续盈利金额')
    shunshou = models.FloatField(null=True, blank=True, verbose_name='顺守')
    nigong = models.FloatField(null=True, blank=True, verbose_name='逆攻')
    loss3 = models.IntegerField(null=True, blank=True, verbose_name='连亏3次的次数')
    loss5 = models.IntegerField(null=True, blank=True, verbose_name='连亏5次的次数')
    weekNum = models.IntegerField(null=True, blank=True, verbose_name='周数')
    weekProfitMoney = models.FloatField(null=True, blank=True, verbose_name='平均周盈利能力')
    weekProfitNum = models.FloatField(null=True, blank=True, verbose_name='平均周交易次数')
    weekProfitrate = models.FloatField(null=True, blank=True, verbose_name='平均周增长率')
    monthNum = models.IntegerField(null=True, blank=True, verbose_name='月数')
    mouthProfitMoney = models.FloatField(null=True, blank=True, verbose_name='平均月盈利能力')
    mouthProfitNum = models.FloatField(null=True, blank=True, verbose_name='平均月交易次数')
    mouthProfitrate = models.FloatField(null=True, blank=True, verbose_name='平均月增长率')
    ylrank = models.FloatField(null=True, blank=True, verbose_name='盈利评分')
    ylrankdtl = models.CharField(max_length=255, null=True, blank=True, verbose_name='盈利评分细节')
    bsrank = models.FloatField( null=True, blank=True, verbose_name='保守评分')
    bsrankdtl = models.CharField(max_length=255, null=True, blank=True, verbose_name='保守评分细节')
    jcrank = models.FloatField(null=True, blank=True, verbose_name='加仓评分')
    jcrankdtl = models.CharField(max_length=255, null=True, blank=True, verbose_name='加仓评分细节')
    spread = models.FloatField(null=True, blank=True, verbose_name='点差')
    notes = models.CharField(max_length=255, null=True, blank=True, verbose_name='备注')
    others = models.CharField(max_length=255, null=True, blank=True, verbose_name='其他')

    class Meta:
        db_table = 'test_report_summary'


class TestReportOrder(models.Model):
    id = models.BigAutoField(primary_key=True)
    reportid = models.BigIntegerField()
    reportname = models.CharField(max_length=255, null=True)
    reporttime = models.DateTimeField(null=True)
    orderid = models.BigIntegerField(null=True)
    chicangNum = models.IntegerField(null=True)
    com = models.CharField(max_length=255, null=True)
    symbol = models.CharField(max_length=255, null=True)
    tp = models.FloatField(null=True)
    sl = models.FloatField(null=True)
    ordertype = models.CharField(max_length=255, null=True)
    opent = models.DateTimeField(null=True)
    openp = models.FloatField(null=True)
    stopt = models.DateTimeField(null=True)
    stopp = models.FloatField(null=True)
    passt = models.IntegerField(null=True)
    dealvol = models.FloatField(null=True)
    seedin = models.FloatField(null=True)
    maxtp = models.FloatField(null=True)
    maxsl = models.FloatField(null=True)
    maxtppoint = models.IntegerField(null=True)
    maxslpoint = models.IntegerField(null=True)
    profit = models.FloatField(null=True)
    prebalance = models.FloatField(null=True)

    @property
    def target_table(self):
        year = self.reporttime[:4]
        return f'test_report_order_'+year

    class Meta:
        managed = False
        db_table = 'test_report_order'
        unique_together = ('reportid', 'chicangNum')

    def save(self, *args, **kwargs):
        if self.opent:
            formatted_opent = datetime.strptime(self.opent, "%Y.%m.%d %H:%M")
            self.opent = formatted_opent.strftime("%Y-%m-%d %H:%M")
        if self.stopt:
            formatted_stopt = datetime.strptime(self.stopt, "%Y.%m.%d %H:%M")
            self.stopt = formatted_stopt.strftime("%Y-%m-%d %H:%M")
        self._meta.db_table = self.target_table
        super().save(*args, **kwargs)
