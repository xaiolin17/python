import re

from selenium import webdriver
from selenium.common import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from django.db.models import Q


# 各个指标阈值
totalprofitYZ = 2000
profitFactorYZ = 5
winrateYZ = 100
benjinProfitRateYZ = 100
maxbenjinbackYZ = 100
maxlirunbackYZ = 100
ordernumYZ = 10000
maxPrelossYZ = 10000
fluctionsYZ = 100
avgRevYZ = 10
weekProfitMoneyYZ = 100
mouthProfitMoneyYZ = 100
shunshouYZ = 0.9  # 越小越好
nigongYZ = 1  # 越大越好

# 权重系数
yllist = [20, 10, 10, 10, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5]
bslist = [15, 5, 5, 5, 10, 10, 5, 10, 10, 5, 5, 5, 5, 5]
jclist = [15, 10, 10, 5, 5, 5, 5, 5, 5, 5, 5, 5, 10, 10]

# 根据变量名匹配值返回
def getHtmlVar(htmlStr, varName):
    regex = r'var\s' + varName + '\s*=\s*"(.*?)";'
    matches = re.findall(regex, htmlStr, re.DOTALL)
    if matches:
        return matches[0]
    else:
        return None


def getWeekAndMonthData(fileUrl):
    options = Options()
    # 启用无界面模式
    options.add_argument('--headless')
    # 创建Chrome浏览器驱动
    driver = webdriver.Chrome(options=options)
    driver.get(fileUrl)

    id_list = ['weekNum', 'weekProfitMoney', 'weekProfitNum', 'weekProfitrate', 'monthNum', 'mouthProfitMoney', 'mouthProfitNum', 'mouthProfitrate', 'sharpe']
    weekAndMonthData = {}
    for id in id_list:
        try:
            element = driver.find_element(By.ID, id)
            weekAndMonthData[id] = element.text
        except NoSuchElementException:
            weekAndMonthData[id] = None
    driver.quit()
    return weekAndMonthData

def is_float(value):
    try:
        float(value)
        return True
    except ValueError:
        return False
def convert_to_q_object(condition):
    if condition.count('<=') == 2:
        value1, field, value2 = condition.split('<=')
        return Q(**{f'{field}__gte': float(value1), f'{field}__lte': float(value2)})
    if '<=' in condition and '<' in str(condition.split('<=')):
        if '<' not in condition.split('<=')[0]:
            value1, str1 = condition.split('<=')
            field, value2 = str1.split('<')
            return Q(**{f'{field}__gte': float(value1), f'{field}__lt': float(value2)})
    if condition.count('>=') == 2:
        value1, field, value2 = condition.split('>=')
        return Q(**{f'{field}__gte': float(value2), f'{field}__lte': float(value1)})

    if '>=' in condition and '>' in str(condition.split('>=')):
        if '>' not in condition.split('>=')[0]:
            value1, str1 = condition.split('>=')
            field, value2 = str1.split('>')
            return Q(**{f'{field}__gt': float(value2), f'{field}__lte': float(value1)})
    if condition.count('<') == 2 and '=' not in condition:
        value1, field, value2 = condition.split('<')
        return Q(**{f'{field}__gt': float(value1), f'{field}__lt': float(value2)})
    if condition.count('<') == 2 and '<=' in condition:
        str1, value2 = condition.split('<=')
        value1, field = str1.split('<')
        return Q(**{f'{field}__gt': float(value1), f'{field}__lte': float(value2)})
    if condition.count('>') == 2 and '=' not in condition:
        value1, field, value2 = condition.split('>')
        return Q(**{f'{field}__gt': float(value2), f'{field}__lt': float(value1)})
    if condition.count('>') == 2 and '>=' in condition:
        str1, value2 = condition.split('>=')
        value1, field = str1.split('>')
        return Q(**{f'{field}__gte': float(value2), f'{field}__lt': float(value1)})
    if '>=' in condition:
        field, value = condition.split('>=')
        if is_float(field):
            field, value = value, field
            return Q(**{f'{field}__lte': float(value)})
        return Q(**{f'{field}__gte': float(value)})
    if '<=' in condition:
        field, value = condition.split('<=')
        if is_float(field):
            field, value = value, field
            return Q(**{f'{field}__gte': float(value)})
        return Q(**{f'{field}__lte': float(value)})
    if '>' in condition:
        field, value = condition.split('>')
        if is_float(field):
            field, value = value, field
            return Q(**{f'{field}__lt': float(value)})
        return Q(**{f'{field}__gt': float(value)})
    if '<' in condition:
        field, value = condition.split('<')
        if is_float(field):
            field, value = value, field
            return Q(**{f'{field}__gt': float(value)})
        return Q(**{f'{field}__lt': float(value)})
    if '=' in condition:
        field, value = condition.split('=')
        if is_float(field):
            field, value = value, field
        return Q(**{f'{field}': float(value)})
    else:
        raise ValueError('Invalid condition format.')





