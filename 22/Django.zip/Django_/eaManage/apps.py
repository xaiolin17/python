from django.apps import AppConfig


class EamanageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eaManage'
