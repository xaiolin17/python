import json
from bs4 import BeautifulSoup
from django.http import JsonResponse, response, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from lxml import etree
import MetaTrader5 as mt5
from datetime import datetime, timedelta

from eaManage.utils import getPassTime, transdate, transdate2, getmql5_data_from_url

def toothrptdle(request):
    return render(request, 'eaManage/othRptAnal.html')

def mql5link(request):
    return render(request, 'eaManage/mql5linkget.html')

# Create your views here.
@csrf_exempt
def analysisEaRpt(request, soup=None):
    # 获取基本数据
    # 获取历史订单并解析
    # 反馈解析结果
    if request.method == 'POST':
        file = request.FILES['file']
        tree = etree.HTML(file.read())
        countleverage = request.POST.get('countleverage')
        if len(countleverage) == 0:
            countleverage = 100
        seeding = request.POST.get('seedin')
        if len(seeding) == 0:
            seeding = 0
        company = tree.xpath('/html/body/div/div/b')[0].text
        account = tree.xpath('/html/body/div/table//tr[1]/td[1]/b')[0].text.split(":")[1]
        name = tree.xpath('/html/body/div/table//tr[1]/td[2]/b')[0].text.split(":")[1]
        currency = tree.xpath('/html/body/div/table//tr[1]/td[3]/b')[0].text.split(":")[1]
        leverage = tree.xpath('/html/body/div/table//tr[1]/td[4]/b')[0].text.split(":")[1]
        reportCreateTime = tree.xpath('/html/body/div/table//tr[1]/td[5]/b')[0].text
        nowPL = tree.xpath("//td[b[contains(text(), 'Floating P/L:')]]/following-sibling::td[@class='mspt']/b")[
            0].text.replace(' ', '')  # 当前持仓浮盈
        nowBalance = tree.xpath("//td[b[contains(text(), 'Balance:')]]/following-sibling::td[@class='mspt']/b")[
            0].text.replace(' ', '')  # 当前结余
        nowEquity = tree.xpath("//td[b[contains(text(), 'Equity:')]]/following-sibling::td[@class='mspt']/b")[
            0].text.replace(' ', '')  # 当前净值
        nowSumProfit = tree.xpath("//td[b[contains(text(), 'Gross Profit:')]]/following-sibling::td[@class='mspt']/b")[
            0].text.replace(' ', '')  # 总盈利
        nowSumLoss = tree.xpath("//td[b[contains(text(), 'Gross Loss:')]]/following-sibling::td[@class='mspt']/b")[
            0].text.replace(' ', '')  # 总亏损
        nowNetProfit = \
            tree.xpath("//td[b[contains(text(), 'Total Net Profit:')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 净盈利
        nowProfitFactor = \
            tree.xpath("//td[b[contains(text(), 'Profit Factor:')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 盈利因子
        nowPayoff = tree.xpath("//td[b[contains(text(), 'Expected Payoff:')]]/following-sibling::td[@class='mspt']/b")[
            0].text.replace(' ', '')  # 预期收益
        nowAbsDrawdown = \
            tree.xpath("//td[b[contains(text(), 'Absolute Drawdown:')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 绝对回撤
        nowMaxDrawdown = \
            tree.xpath("//td[b[contains(text(), 'Maximal Drawdown:')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 最大回撤
        nowRelDrawdown = \
            tree.xpath("//td[b[contains(text(), 'Relative Drawdown:')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 相对回撤
        nowSumTrades = tree.xpath("//td[b[contains(text(), 'Total Trades:')]]/following-sibling::td[@class='mspt']/b")[
            0].text.replace(' ', '')  # 交易单量
        nowSellNum = \
            tree.xpath("//td[b[contains(text(), 'Short Positions (won %):')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 空单
        nowBuyNum = \
            tree.xpath("//td[b[contains(text(), 'Long Positions (won %):')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 多单
        nowProfitNum = \
            tree.xpath(
                "//td[b[contains(text(), 'Profit Trades (% of total):')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 盈利单
        nowLossNum = \
            tree.xpath("//td[b[contains(text(), 'Loss trades (% of total):')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 亏损单
        nowMaxProfit = tree.xpath("//td[b[contains(text(), 'Largest')]]/following-sibling::td[@class='mspt'][1]/b")[
            0].text.replace(' ', '')  # 最大盈利
        nowMaxLoss = tree.xpath("//td[b[contains(text(), 'Largest')]]/following-sibling::td[@class='mspt'][2]/b")[
            0].text.replace(' ', '')  # 最大亏损
        nowAvgProfit = tree.xpath("//td[b[contains(text(), 'Average')]]/following-sibling::td[@class='mspt'][1]/b")[
            0].text.replace(' ', '')  # 平均盈利
        nowAvgLoss = tree.xpath("//td[b[contains(text(), 'Average')]]/following-sibling::td[@class='mspt'][2]/b")[
            0].text.replace(' ', '')  # 平均亏损
        nowMaxiPNum = tree.xpath("//td[b[contains(text(), 'Maximum')]]/following-sibling::td[@class='mspt'][1]/b")[
            0].text.replace(' ', '')  # 最大盈利次数
        nowMaxiLNum = tree.xpath("//td[b[contains(text(), 'Maximum')]]/following-sibling::td[@class='mspt'][2]/b")[
            0].text.replace(' ', '')  # 最大亏损次数
        nowMaxiPPrice = \
            tree.xpath(
                "//td[b[contains(text(), 'consecutive profit (count):')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 最大盈利金额
        nowMaxiLPrice = \
            tree.xpath("//td[b[contains(text(), 'consecutive loss (count):')]]/following-sibling::td[@class='mspt']/b")[
                0].text.replace(' ', '')  # 最大亏损金额
        nowAvgPNum = \
            tree.xpath("//td[b[contains(text(), 'consecutive wins:')]]/following-sibling::td[@class='mspt'][1]/b")[
                0].text.replace(' ', '')  # 平均盈利次数
        nowAvgLNum = \
            tree.xpath("//td[b[contains(text(), 'consecutive losses:')]]/following-sibling::td[@class='mspt'][1]/b")[
                0].text.replace(' ', '')  # 平均亏损次数

        # 如果基本数据能取到就连接到mt5
        mt5.initialize()
        table1data = '['
        jieyu = ''
        fuying = ''
        fukui = ''
        balance = float(seeding)
        inoroutstr = ''  # 用来监控出入金情况
        buyWin = 0
        sellWin = 0
        first_time = True
        startTradTime = ''
        endTradTime = ''
        closeTime = ''
        rows = tree.xpath('/html/body/div/table//tr')[3:]
        for index, row in enumerate(rows):
            cells = row.xpath('./td')
            ticket = cells[0].text
            if ticket is None or ticket.strip() == '':
                endTradTime = closeTime
                break
            openTime = cells[1].text
            if first_time:
                startTradTime = openTime
                first_time = False
            tradeType = cells[2].text
            if tradeType == 'balance':
                inorout = cells[4].text
                balance += float(inorout.replace(' ', ''))
                inoroutstr += "['" + transdate(openTime) + "','" + str(round(balance, 2)) + "','" + \
                              inorout.replace(' ', '') + "'],"
                # 表格数据
                tableDict = {'ticket': ticket, 'tradeType': tradeType, 'profit': inorout, 'balance': round(balance, 2)}
                table1data += str(tableDict) + ','
                continue
            # 统计空单胜率和多单胜率
            if tradeType == 'buy' and float(cells[13].text.replace(' ', '')) >= 0:
                buyWin += 1
            if tradeType == 'sell' and float(cells[13].text.replace(' ', '')) >= 0:
                sellWin += 1
            size = cells[3].text
            item = cells[4].text
            openPrice = cells[5].text
            sl = cells[6].text
            tp = cells[7].text
            closeTime = cells[8].text
            closePrice = cells[9].text
            commission = cells[10].text
            taxes = cells[11].text
            swap = cells[12].text
            profit = cells[13].text
            passTime = getPassTime(openTime, closeTime)
            opent = openTime.split(' ')
            opent1 = opent[0].split('.')
            opent2 = opent[1].split(':')
            closet = closeTime.split(' ')
            close1 = closet[0].split('.')
            close2 = closet[1].split(':')

            #  设置endmin，防止只有1分钟以内取不到柱状图
            endmin = int(close2[1])
            if passTime <= 1:
                endmin = int(close2[1]) + 1

            start_time = datetime(int(opent1[0]), int(opent1[1]), int(opent1[2]), int(opent2[0]), int(opent2[1]),
                                  int(opent2[2]))  # 开始时间（年、月、日、时、分）
            end_time = datetime(int(close1[0]), int(close1[1]), int(close1[2]), int(close2[0]), endmin,
                                int(close2[2]))  # 结束时间（年、月、日、时、分）

            # 从 MetaTrader 5 获取历史价格数据

            # timezone = pytz.timezone("Etc/UTC") # 将时区设置为UTC  以测试报告为准xa
            symbol = item.split('.')[0].upper()  # 要获取价格的货币对
            rate_info = mt5.copy_rates_range(symbol, mt5.TIMEFRAME_M1, start_time, end_time)
            oneMaxSl = 0  # 浮亏
            oneMaxTp = 0  # 浮盈
            oneTpVal = 0
            oneSlVal = 0
            if len(rate_info) == 0:
                oneMaxSl = 0  # 浮亏
                oneMaxTp = 0  # 浮盈
                oneTpVal = balance
                oneSlVal = balance
            else:
                # 初始化最大值和最小值
                max_price = rate_info[0]["high"]
                min_price = rate_info[0]["low"]

                # 遍历历史价格数据，找到最大值和最小值
                for rate in rate_info:
                    if rate["high"] > max_price:
                        max_price = rate["high"]
                    if rate["low"] < min_price:
                        min_price = rate["low"]
                maxtp = 0.0
                maxsl = 0.0
                if tradeType == 'buy':
                    maxtp = max_price
                    maxsl = min_price
                if tradeType == 'sell':
                    maxsl = max_price
                    maxtp = min_price
                oneMaxSl = abs(float(openPrice) - maxsl) * float(size) * float(countleverage)  # 浮亏
                oneMaxTp = abs(float(openPrice) - maxtp) * float(size) * float(countleverage)  # 浮盈
                oneTpVal = balance + round(oneMaxTp, 2)
                oneSlVal = balance - round(oneMaxSl, 2)
            balance += float(profit)
            # 表格数据
            tableDict = {'ticket': ticket, 'tradeType': tradeType, 'size': size, 'item': item, 'openTime': openTime,
                         'openPrice': openPrice, 'tp': tp, 'sl': sl, 'closeTime': closeTime, 'closePrice': closePrice,
                         'maxTp': round(oneMaxTp, 2), 'maxSl': round(oneMaxSl, 2), 'passTime': passTime,
                         'commission': commission,
                         'taxes': taxes, 'swap': swap, 'profit': profit, 'balance': round(balance, 2)}
            table1data += str(tableDict) + ','
            # 结余数据
            jieyu += "['" + transdate(closeTime) + "'," + str(round(balance, 2)) + "],"
            # 浮盈
            fuying += "['" + transdate(closeTime) + "'," + str(round(oneTpVal, 2)) + "],"
            # 浮亏
            fukui += "['" + transdate(closeTime) + "'," + str(round(oneSlVal, 2)) + "],"
            # 摘要
        weekNum = round(getPassTime(startTradTime, endTradTime)/10080,2)
        weekProfit = round(float(nowNetProfit)/weekNum,2)
        summary = {"company": company, "account": account, "name": name, "currency": currency, "leverage": leverage,
                   "reportCreateTime": reportCreateTime, "nowPL": nowPL, "nowBalance": nowBalance,
                   "nowEquity": nowEquity,"weekNum":str(weekNum),"weekProfit":str(weekProfit),
                   "nowSumProfit": nowSumProfit, "nowSumLoss": nowSumLoss, "nowNetProfit": nowNetProfit,
                   "nowProfitFactor": nowProfitFactor, "nowPayoff": nowPayoff,
                   "nowAbsDrawdown": nowAbsDrawdown, "nowMaxDrawdown": nowMaxDrawdown,
                   "nowRelDrawdown": nowRelDrawdown, "nowSumTrades": nowSumTrades, "nowSellNum": nowSellNum,
                   "nowBuyNum": nowBuyNum, "nowProfitNum": nowProfitNum, "nowLossNum": nowLossNum,
                   "nowMaxProfit": nowMaxProfit, "nowMaxLoss": nowMaxLoss,
                   "nowAvgProfit": nowAvgProfit, "nowAvgLoss": nowAvgLoss, "nowMaxiPNum": nowMaxiPNum,
                   "nowMaxiLNum": nowMaxiLNum, "nowMaxiPPrice": nowMaxiPPrice,
                   "nowMaxiLPrice": nowMaxiLPrice, "nowAvgPNum": nowAvgPNum, "nowAvgLNum": nowAvgLNum,
                   "buyWinProportion": str(buyWin) + '/' + nowBuyNum.split('(')[0],
                   "buyWinRatio": str(round(buyWin * 100 / float(nowBuyNum.split('(')[0]), 2)) + '%',
                   "sellWinProportion": str(sellWin) + '/' + nowSellNum.split('(')[0],
                   "sellWinRatio": str(round(sellWin * 100 / float(nowSellNum.split('(')[0]), 2)) + '%', }
        summaryjson = json.dumps(summary)
        table1data = table1data[:-1].replace("'", "\"") + ']'
        jieyu = '[' + jieyu[:-1] + ']'
        fuying = '[' + fuying[:-1] + ']'
        fukui = '[' + fukui[:-1] + ']'
        inoroutstr = '[' + inoroutstr[:-1] + ']'
        response_data = {
            'message': 'Success',
            'table1data': table1data,
            'jieyu': jieyu,
            'fuying': fuying,
            'fukui': fukui,
            'iodata': inoroutstr,
            'summaryjson': summaryjson,
        }
        mt5.shutdown()
    return JsonResponse(response_data)


@csrf_exempt
def getMt5BarData(request):
    if request.method == 'POST':
        symbol = request.POST.get('symbol')
        timeframe = request.POST.get('timeframe')
        openTime = request.POST.get('openTime')
        closeTime = request.POST.get('closeTime')

        format_str = '%Y.%m.%d %H:%M:%S'
        openTime = datetime.strptime(openTime, format_str)
        closeTime = datetime.strptime(closeTime, format_str)
        if (timeframe.split('_')[1] == 'M1'):
            openTime = openTime - timedelta(minutes=20)
            closeTime = closeTime + timedelta(minutes=20)
        if (timeframe.split('_')[1] == 'M5'):
            openTime = openTime - timedelta(minutes=20 * 5)
            closeTime = closeTime + timedelta(minutes=20 * 5)
        if (timeframe.split('_')[1] == 'M15'):
            openTime = openTime - timedelta(minutes=20 * 15)
            closeTime = closeTime + timedelta(minutes=20 * 15)
        if (timeframe.split('_')[1] == 'M30'):
            openTime = openTime - timedelta(minutes=20 * 30)
            closeTime = closeTime + timedelta(minutes=20 * 30)
        if (timeframe.split('_')[1] == 'H1'):
            openTime = openTime - timedelta(hours=20)
            closeTime = closeTime + timedelta(hours=20)
        if (timeframe.split('_')[1] == 'H4'):
            openTime = openTime - timedelta(hours=20 * 4)
            closeTime = closeTime + timedelta(hours=20 * 4)
        if (timeframe.split('_')[1] == 'D1'):
            openTime = openTime - timedelta(days=20)
            closeTime = closeTime + timedelta(days=20)

        opent = str(openTime).split(' ')
        opent1 = opent[0].split('-')
        opent2 = opent[1].split(':')
        closet = str(closeTime).split(' ')
        close1 = closet[0].split('-')
        close2 = closet[1].split(':')
        start_time = datetime(int(opent1[0]), int(opent1[1]), int(opent1[2]),
                              int(opent2[0]), int(opent2[1]), int(opent2[2]))  # 开始时间（年、月、日、时、分）
        end_time = datetime(int(close1[0]), int(close1[1]), int(close1[2]),
                            int(close2[0]), int(close2[1]), int(close2[2]))
        if not mt5.initialize():
            response_data = {
                'message': 'MT5链接失败',
            }
            return JsonResponse(response_data)
        rate_info = mt5.copy_rates_range(symbol, eval(timeframe), start_time, end_time)
        if not mt5.initialize():
            response_data = {
                'message': str(mt5.last_error()),
            }
            mt5.shutdown()
            return JsonResponse(response_data)
        print(mt5.last_error())
        xdata = '['
        ydata = '['
        for rate in rate_info:
            xdata += "'" + transdate2(str(rate["time"])) + "',"
            ydata += "[" + str(rate["open"]) + "," + str(rate["close"]) \
                     + "," + str(rate["low"]) + "," + str(rate["high"]) + "],"
        xdata = xdata[:-1] + ']'
        ydata = ydata[:-1] + ']'
    response_data = {
        'message': 'Success',
        'xdata': xdata,
        'ydata': ydata,
    }
    mt5.shutdown()
    return JsonResponse(response_data)

@csrf_exempt
def clickdef(request):
    try:
        if request.method == 'POST':
            #获取传递的url
            url = request.POST.get('urltest')
            #自动化爬取数据
            url_get_data = getmql5_data_from_url(url)
            print('爬取到数据： ', len(url_get_data))
            #


    except Exception as e:
        error_message = '请求失败! ' + str(e)
        return HttpResponse(error_message)

    response_data = {
        'message': 'Success',
        'url': url,
    }
    return JsonResponse(response_data)


# Create your views here.
