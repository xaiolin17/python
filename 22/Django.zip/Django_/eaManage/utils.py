import math
import random
import time
from bs4 import BeautifulSoup
from datetime import datetime
import requests
from fake_useragent import UserAgent
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

def getPassTime(startTime, endTime):
    time_format = "%Y.%m.%d %H:%M:%S"
    startTime = datetime.strptime(startTime, time_format)
    endTime = datetime.strptime(endTime, time_format)

    time_diff = endTime - startTime
    minutes_diff = time_diff.total_seconds() / 60
    return math.ceil(minutes_diff)

def transdate(time):
    # 转换为datetime对象
    original_format = "%Y.%m.%d %H:%M:%S"
    converted_datetime = datetime.strptime(time, original_format)

    # 转换为新的字符串格式
    new_format = "%Y-%m-%d %H:%M:%S"
    converted_string = converted_datetime.strftime(new_format)

    # 打印转换后的字符串
    return converted_string

def transdate2(time):
    # 使用 datetime 模块进行转换
    time = int(time)
    dt_object = datetime.fromtimestamp(time)

    # 将转换后的时间格式化为字符串
    formatted_time = dt_object.strftime('%Y.%m.%d %H:%M:%S')

    return formatted_time


"""
常量声明
"""
USERNAME = 'xiaolin17'
PASSWORD = 'CdDEFAcw'
def getmql5_data_from_url(url):
    options = Options()
    driver = webdriver.Chrome(options=options)
    driver.get(url + '#!tab=history')
    # 点击登录
    login_btn = driver.find_element(By.XPATH, '//a[text()="登录"]')
    login_btn.click()
    # 输入账号密码
    input_username = driver.find_element(By.XPATH, '//input[@id="Login"]')
    input_username.send_keys(USERNAME)

    input_password = driver.find_element(By.XPATH, '//input[@id="Password"]')
    input_password.send_keys(PASSWORD)

    # 提交登录
    submit_btn = driver.find_element(By.XPATH, '//input[@id="loginSubmit"]')
    submit_btn.click()

    time.sleep(3)
    # 点击交易历史记录
    history_btn = driver.find_element(By.ID, 'tab_history')
    history_btn.click()

    result = []
    # 拿到页码方便后序翻页
    len_page = int(driver.find_element("class name", "paginatorEx").text[-1])

    for page in range(1, len_page + 1):
        # 点击翻页
        page_btn = driver.find_element(By.XPATH, '//a[text()=' + str(page) + ']')
        page_btn.click()
        time.sleep(1)
        # 包含数据的div ID
        data = driver.find_element("id", "signal_tab_content_positions")
        # 拿到tbody表格html
        soupdiv = BeautifulSoup(data.get_attribute('outerHTML'), 'lxml')
        souptbody = soupdiv.find_all(name='tbody')
        # 获取每一行
        for tr in souptbody[0].find_all(name='tr'):
            tdlist = tr.find_all(name='td')
            # print(tdlist[-1])
            # print('-------------------------------------')
            # print(tdlist[0])
            # print("####################################")

            # 获取每一格
            dict = {}
            for i in range(len(tdlist)):
                tdlist_copy = tdlist.copy()
                if i == 0:
                    dict['时间1'] = tdlist[i].text
                elif i == 1:
                    dict['类型'] = tdlist[i].text
                elif i == 2:
                    dict['交易量'] = tdlist[i].text
                elif i == 3:
                    dict['交易品种'] = tdlist[i].text
                elif i == 4:
                    dict['价格1'] = tdlist[i].text
                elif i == 5:
                    dict['时间2'] = tdlist[i].text
                elif i == 6:
                    dict['价格2'] = tdlist[i].text
                elif i == 7:
                    dict['佣金'] = tdlist[i].text
                elif i == 8:
                    dict['库存费'] = tdlist[i].text
                elif i == 9:
                    dict['利润'] = tdlist[i].text
            # 每一行数据放到一个位置
            result.append(dict)

    driver.quit()

    return result[:-1]
