"""
URL configuration for zhiqiang project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from eaManage.views import toothrptdle, analysisEaRpt, getMt5BarData, mql5link, clickdef
from newsManage.views import tonews, getHotNews, addKeysWords, delKeysWords, addRecStocks, getRecStocks
from testapp import views
from testapp.views import getrept

from reportDle.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/', views.index),
    path('test/', views.test),
    # 重定向
    path('reportdle/', mtrd),
    path('eamanage/', toothrptdle),
    path('newsmanage/', tonews),
    path('mql5link/', mql5link),
    # 请求
    path('test/getrept', getrept),
    path('reportdle/tosrchrpt', tosrchrpt),
    path('reportdle/upload_file', upload_file),
    path('reportdle/openSourceRpt', openSourceRpt),
    path('eamanage/analysisEaRpt', analysisEaRpt),
    path('eamanage/getMt5BarData', getMt5BarData),
    path('newsmanage/getHotNews', getHotNews),
    path('newsmanage/addKeysWords', addKeysWords),
    path('newsmanage/delKeysWords', delKeysWords),
    path('newsmanage/addRecStocks', addRecStocks),
    path('newsmanage/getRecStocks', getRecStocks),
    path('mql5link/clickdef', clickdef),

]
